<?php 

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Permissions;
use DB;
use Session;

class StockController extends Controller {
    
    protected $permissions;
    public $permission_val = 0;
    public $privillige_menu = array();
    
    function __construct(Permissions $permissions)
    {
        $this->permissions = $permissions;
        
        $this->middleware(function ($request, $next){
            $permission_type = Session::get('permission_type');
            $menu_permission = $this->permissions->has_permission('website_settings',$permission_type);
            if(!$menu_permission->isEmpty()){
                $menu_previllige = $this->permissions->has_previllige_permission($permission_type);
                $this->permission_val = $menu_permission[0]->permission_level;
                $this->privillige_menu = $menu_previllige;
                return $next($request);
            }else{
                return redirect('/permission_denied');
            }
        });
    }

	public function index()
	{
	    $title = 'Item Category List';
        $active_menu = 'stock';
        $current_menu = 'stock_category';
   	    return view("stock.index",['title' => $title,'active_menu' => $active_menu, 'current_menu' => $current_menu]);
	}
	
	
		public function stock_category()
	{
	    $title = 'Item Category List';
        $active_menu = 'stock';
        $current_menu = 'stock_category';
        $stock_category = DB::table('stock_category')
					        ->orderBy('id_stock_category','DESC')
					        ->get();
   	    return view("stock.stock_category",compact('title','active_menu', 'current_menu' ,'stock_category'));
	}
	
	public function stock_product()
	{
	    $title = 'Item Product List';
        $active_menu = 'stock';
        $current_menu = 'stock_product';
        $stock_product = DB::table('stock_product')
					        ->orderBy('id_stock_category','DESC')
					        ->get();
   	    return view("stock.stock_product",compact('title','active_menu', 'current_menu' ,'stock_product'));
	}
	
	public function view_details($id)
	{
	    $stock_product_id = base64_decode($id);
	    $title = 'Item Product details';
        $active_menu = 'stock';
        $current_menu = 'stock_product';
        
        $stock_product=DB::table('stock_product')
                        ->where('id_stock_product',$stock_product_id)
                        ->first();
        
   	   return view("stock.view_details",compact('title','active_menu', 'current_menu','stock_product' ));
	}
	
	public function product_category_insert(Request $request)
	{
        $admin_id=Session::get('admin_id');
        $data=array(); 
		$data['created_by']=$admin_id;
		$data['name_stock_category']=$request->category_name;
		$data['parent_id_stock_category']=$request->parent_id;
		$data['status_stock_category']='1';
		$data['created_at']=date('Y-m-d H:i:s');
		
		
		
		
		DB::table('stock_category')->insert($data);
        
   	   return redirect()->back();
   	}
   	
   	public function product_category_update(Request $request,$cate_id)
	{
        $data=array(); 
		$data['name_stock_category']=$request->category_name;
		$data['parent_id_stock_category']=$request->parent_id;
		$data['status_stock_category']=$request->status;
		$data['updated_at']=date('Y-m-d H:i:s');
		
		DB::table('stock_category')
        ->where('id_stock_category',$cate_id)  
        ->update($data);
        
   	   return redirect()->back();
   	}
   	
   	public function stock_product_insert_info(Request $request)
	{
        $data=array(); 
		$data['name_stock_product']=$request->product_title;
		$data['id_stock_category']=$request->product_category;
		$data['product_highlights']=$request->product_highlights;
		$data['details_stock_product']=htmlentities($request->product_description);
		$data['price_stock_product']=$request->price;
		$data['sell_price_stock_product']=$request->sale_price;
		
		$data['video_url']=$request->video_url;
		$data['warranty_type']=$request->warranty_type;
		$data['warranty_period']=$request->warranty_period;
		$data['warranty_period_type']=$request->warranty_period_type;
		$data['warranty_policy']=$request->warranty_policy;
		$data['weight']=$request->weight;
		$data['length']=$request->length; 
		$data['width']=$request->width;
		$data['height']=$request->height;
		$data['battery']=$request->battery;
		$data['flammable']=$request->flammable;
		$data['liquid']=$request->liquid;
		$data['seller_id']=$request->seller_id;
		$data['company_id']=$request->company_id;
		$data['quantity']=$request->quantity;
		$data['low_quantity']=$request->low_quantity;
		$data['what_in_box']=$request->what_in_box;
		
		$data['taxable']=$request->taxable;
		$data['tax_id']=$request->tax_id;
		$data['in_stock']=$request->in_stock;
		$data['tags']=$request->tags;
		$data['status_stock_product']=$request->status;
		$data['barcode_product']=$request->bar_code;
		
        if($request->hasfile('picture')) {
            $simage=$request->file('picture');
            $info = getimagesize($simage);
    
            if ($info['mime'] == 'image/jpeg') 
                $image_n = imagecreatefromjpeg($simage);
    
            elseif ($info['mime'] == 'image/gif') 
                $image_n = imagecreatefromgif($simage);
    
            elseif ($info['mime'] == 'image/png') 
                $image_n = imagecreatefrompng($simage);
                
            $name =hexdec(uniqid());
            imagejpeg($image_n, "public/store_product/".$name.".jpeg", 50);
            
    		$data['image_stock_product']=$name.".jpeg";
        }else{
           $data['image_stock_product']=''; 
        }
        
		
		$insert_id = DB::table('stock_product')->insertGetId($data);
		
	    if($request->hasfile('imageFile')) {
            foreach($request->file('imageFile') as $image)
            {
                $info = getimagesize($image);

                if ($info['mime'] == 'image/jpeg') 
                    $image_n = imagecreatefromjpeg($image);
        
                elseif ($info['mime'] == 'image/gif') 
                    $image_n = imagecreatefromgif($image);
        
                elseif ($info['mime'] == 'image/png') 
                    $image_n = imagecreatefrompng($image);
                    
                $name =hexdec(uniqid());
                imagejpeg($image_n, "public/store_product/".$name.".jpeg", 50);
                
        		$p_image = $name.".jpeg";
        		
        		$stock_product_picture = array(
                    'product_id' => $insert_id,
                    'picture' => $p_image
                );
                DB::table('stock_product_picture')->insert($stock_product_picture);
            }
        }
        
		$request->session()->flash('status','Product added sucessfully.');
	
		return redirect('/stock_product_list');
		
   	    
	}
	
	public function stock_product_update_info(Request $request, $id)
	{
	    $p_id = base64_decode($id);
	    
	    $image_old= DB::table('stock_product')->where('id_stock_product',$p_id)->first();
	    
	    $file = $image_old->image_stock_product;
	  
        $data=array(); 
		$data['name_stock_product']=$request->product_title;
		$data['id_stock_category']=$request->product_category;
		$data['product_highlights']=$request->product_highlights;
		$data['details_stock_product']=htmlentities($request->product_description);
		$data['price_stock_product']=$request->price;
		$data['sell_price_stock_product']=$request->sale_price;
		
		$data['video_url']=$request->video_url;
		$data['warranty_type']=$request->warranty_type;
		$data['warranty_period']=$request->warranty_period;
		$data['warranty_period_type']=$request->warranty_period_type;
		$data['warranty_policy']=$request->warranty_policy;
		$data['weight']=$request->weight;
		$data['length']=$request->length; 
		$data['width']=$request->width;
		$data['height']=$request->height;
		$data['battery']=$request->battery;
		$data['flammable']=$request->flammable;
		$data['liquid']=$request->liquid;
		$data['seller_id']=$request->seller_id;
		$data['company_id']=$request->company_id;
		$data['quantity']=$request->quantity;
		$data['low_quantity']=$request->low_quantity;
		$data['what_in_box']=$request->what_in_box;
		
		$data['taxable']=$request->taxable;
		$data['tax_id']=$request->tax_id;
		$data['in_stock']=$request->in_stock;
		$data['tags']=$request->tags;
		$data['status_stock_product']=$request->status;
		$data['barcode_product']=$request->bar_code;
		
		
		
        if($request->file('picture')){
            if($file){
            if(file_exists("public/store_product/".$file)){
    	        unlink("public/store_product/".$file);
    	    }
            }
            
            $image=$request->file('picture');
            $info = getimagesize($image);
    
            if ($info['mime'] == 'image/jpeg') 
                $image_n = imagecreatefromjpeg($image);
    
            elseif ($info['mime'] == 'image/gif') 
                $image_n = imagecreatefromgif($image);
    
            elseif ($info['mime'] == 'image/png') 
                $image_n = imagecreatefrompng($image);
                
            $name =hexdec(uniqid());
            imagejpeg($image_n, "public/store_product/".$name.".jpeg", 50);
            
    		$data['image_stock_product']=$name.".jpeg";
        }
		
		DB::table('stock_product')->where('id_stock_product',$p_id)->update($data);
		/*
	    $files=$request->file('image');
		
		$product = DB::table('store_product')->where('product_title',$request->product_title)->first();
        
        foreach($files as $m_image){
            if($m_image) {
                $store_product_picture = array(
                    'product_id' => $product->id,
                    'picture' => $m_image,
                    
                );
                DB::table('store_product_picture')->insert($store_product_picture);
            }
        }*/
		$request->session()->flash('status','Product updated sucessfully.');
	
		return redirect('/stock_product_list');
		
   	    
	}
	
	public function stock_product_file_update(Request $request, $product_id)
	{
        
	if($request->hasfile('imageFile'))
		 {
	        foreach($request->file('imageFile') as $image)
            {
                $info = getimagesize($image);

                if ($info['mime'] == 'image/jpeg') 
                    $image_n = imagecreatefromjpeg($image);
        
                elseif ($info['mime'] == 'image/gif') 
                    $image_n = imagecreatefromgif($image);
        
                elseif ($info['mime'] == 'image/png') 
                    $image_n = imagecreatefrompng($image);
                    
                $name =hexdec(uniqid());
                imagejpeg($image_n, "public/store_product/".$name.".jpeg", 50);
                
        		$p_image = $name.".jpeg";
        		
        		$stock_product_picture = array(
                    'product_id' => $product_id,
                    'picture' => $p_image
                );
                DB::table('stock_product_picture')->insert($stock_product_picture);
            }
        }
        
		$request->session()->flash('status','Image added sucessfully.');
	
		return redirect('stock_product_file_edit/'.base64_encode($product_id));
	}
}