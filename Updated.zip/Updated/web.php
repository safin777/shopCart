<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// home controller
Route::get('/','HomeController@index');
Route::post('/send_download_link', 'HomeController@send_download_link');
Route::post('/client_sign_up', 'ClientSignUpController@SignUpValidation');


//package controller

// Route::get('/packages/{Pid}','PackageController@package_by_category');
Route::get('/package_details/{Pid}','PackageController@package_details');
Route::get('/all_services','PackageController@all_package');  
Route::get('/packages/{Pid}','PackageController@package_by_category_new');
Route::get('/packages_active/{Pid}','PackageController@package_by_category_active');
Route::get('/packages_new/{Pid}','PackageController@package_by_category_tab');
Route::post('/package-add-cart/{id}', 'StoreProductController@cart_add_package');
Route::post('/store-add-review/{id}', 'StoreProductController@review_add_product');

Route::post('/add_img', 'StoreProductController@add_img');



// SSLCOMMERZ Start
Route::get('/example1', 'SslCommerzPaymentController@exampleEasyCheckout');
Route::get('/example2', 'SslCommerzPaymentController@exampleHostedCheckout');

Route::any('/pay', 'SslCommerzPaymentController@index');
Route::any('/pay-via-ajax', 'SslCommerzPaymentController@payViaAjax');

Route::any('/success', 'SslCommerzPaymentController@success');
Route::any('/fail', 'SslCommerzPaymentController@fail');
Route::any('/cancel', 'SslCommerzPaymentController@cancel');

Route::any('/ipn', 'SslCommerzPaymentController@ipn');
//SSLCOMMERZ END



// refer controller
Route::get('/referral','ReferController@index');


//blog



Route::get('/blog','BlogController@all_blogs');
Route::get('/all_blogs_by_category/{id}', 'BlogController@blogs_by_category');
Route::get('/all_blogs_by_tag/{id}', 'BlogController@blogs_by_tag');
Route::any('/search_blog','BlogController@search_blog');

Route::get('/blog_post/{id}/{permalink}', 'BlogController@blog_post');

/*
Route::get('/', function () {
    return view('home.home');
});
*/

Route::get('/products', function () {
    return view('products');
});

Route::get('/store_product_details/{id}', 'StoreProductController@product_details');
Route::get('/store_all_products', 'StoreProductController@products_all');
Route::get('/store_products_by_category/{id}', 'StoreProductController@products_by_category');
Route::post('/store-add-cart/{id}', 'StoreProductController@cart_add_product');

Route::post('/update_cart/{cart_id}','StoreProductController@update_cart');
Route::post('/delete_cart/{cart_id}','StoreProductController@delete_cart');
Route::get('/clear_cart','StoreProductController@clear_cart');


Route::get('/store_product', function () {
    return view('store_product');
});
Route::get('/cart', 'StoreProductController@cart_view');

Route::get('/store_order_confirm', function () {
    $title="Checkout";
    return view('store.store_order_confirm',compact('title'));
});
Route::get('/store_my_order', function () {
    $title="My orders";
    return view('store.store_my_order',compact('title'));
});

Route::get('/store_cart', function () {
    return view('store_cart');
});

Route::get('/store_checkout','StoreProductController@store_checkout');

Route::get('/store_confirm_order', function () {
    $title="Confirm order";
    return view('store_confirm_order',compact('title'));
});



Route::get('/products/product_details', function () {
    return view('product_details');
});


Route::get('/profile', function () {
    return view('profile');
});


Route::get('getIdentityInfo', 'ClientLoginController@getIdentityInfo');

Route::get('/mobile_login', function () {
    return view('mobile_login');
});





Route::get('/otp_test', function () {
    return view('otp_test');
});

Route::get('/otp', function () {
    return view('otp');
});




Route::get('/contact', function () {
    return view('contact_us_new');
});


Route::get('/contact_us', function () {
    return view('contact_us');
});



Route::get('/invoice_details', function () {
    return view('invoice_details');
});


Route::get('/web_page/{x}', 'PageController@blank_page');



Route::get('/meeting', function () {
    return view('online_meeting');
});


Route::get('/product_details', function () {
    return view('product_details_ajax'); 
});


Route::get('/refer', function () {
    return view('refer');
});


Route::get('/task_request', function () {
    return view('task_request');
});



Route::get('/task_temp', function () {
    return view('task_temp_disconnect');
});


Route::get('/task_shifting', function () {
    return view('task_shifting');
});



/*

Route::get('/connection_details_old', function () {
    return view('connection_details');
});

Route::get('/connection_details', function () {
    return view('connection_details_new');
});
*/



Route::get('/home2', function () {
    return view('home.home2');
});


Route::get('/home3', function () {
    return view('home.home3');
});

Route::get('/home4', function () {
    return view('home.home4');
});


Route::get('/task_new', function () {
    return view('task_new');
});


Route::get('/task_latest', function () {
    return view('task_latest');
});
Route::get('/contact_latest', function () {
    return view('contact_us_latest');
});

Route::get('/links', function () {
    return view('links');
});
Route::get('/link','HomeController@link');

//invoice
Route::get('/invoice_list','InvoiceController@invoice_all');
Route::get('/invoice_pending','InvoiceController@invoice_pending');
Route::get('/invoice_due','InvoiceController@invoice_due');
Route::get('/invoice_partially_paid','InvoiceController@invoice_partially_paid');
Route::get('/invoice_paid','InvoiceController@invoice_paid');
Route::get('/invoice_cancel','InvoiceController@invoice_cancel');
Route::get('invoice/download/{id}','InvoiceController@download_invoice');

//connection
Route::get('/connection','ConnectionController@connection_all');
Route::get('/connection_details/{id}', 'ConnectionController@connection_details');
Route::get('/task_request1','ConnectionController@task_request');
Route::get('/shifting_request','ConnectionController@shifting_request');
Route::get('/temporary_request','ConnectionController@temporary_request');
Route::post('/task_request/{id}', 'TaskController@task_request');
Route::post('/shifting_request/{id}', 'TaskController@shifting_request');
Route::post('/temporary_disconnection_request/{id}', 'TaskController@temporary_disconnection_request');

//task
Route::get('/task_list','TaskController@task_all');
Route::get('/task_details/{id}', 'TaskController@task_details');

//client Login
Route::post('/client-mobile-login', 'ClientLoginController@client_mobile_login');
Route::post('/client-username-login', 'ClientLoginController@client_username_login');

Route::get('/otp/{otp}/{phone_number}', 'ClientLoginController@get_otp');
Route::post('/verify_otp', 'ClientLoginController@otp_verify');
Route::post('/resend_otp', 'ClientLoginController@resend_otp');
Route::get('/logout', 'ClientLoginController@logout'); 
Route::get('/logout_to_home', 'ClientLoginController@logout_to_home');


//profile controller
Route::get('/profile', 'ClientProfileController@client_profile');
Route::get('/signup', 'ClientSignupController@signup');
Route::post('/client_change_pass','ClientProfileController@changePass');
Route::post('/client_edit_info','ClientProfileController@editInfo');
Route::post('/client_change_pic','ClientProfileController@changePic'); 
Route::post('/client_edit_address/{id}','ClientProfileController@edit_address');
Route::post('/client_add_address','ClientProfileController@addAddress');



//contact us
Route::get('/contacttest', 'ClientLoginController@contact_mail');



 


Route::get('/subscription_all', function () {
    return view('subscription_all');
});


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
