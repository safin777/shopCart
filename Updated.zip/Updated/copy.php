<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use DB;
use App\User;
use App\Http\Requests;
use Session;
use Mail;
use Toastr;


class ClientSignupController extends Controller
{
    public function signup(Request $request)
    {
        $title="Signup";
        return view('signup.signup',compact('title'));
    }


    public function SignUpValidation(Request $request)
    {
        $name= $request->name;
        $email= $request->email;
        $password= $request->password;
        $dob= $request->dob;
        $profile_image= $request->file;

        $identity_type = $request->identity_type;

        //  national id image upload
        $national_id_number = $request->identity_info;
        $national_id_front = $request->fileNational;
        $national_id_back = $request->filebackNational;

        //passport image

        $passport_image = $request->filepassport;

        //birth certificate

        $birth_certificate_info = $request->filebirth;

        //driving license
        $driving_license_front= $request->filelicense;
        $driving_license_back= $request->filebacklicense;

        // checkbox 

        $accept_terms = $request->checkbox_fill_1;

        $result=DB::table('client')
                ->where('email',$email)
                ->first();
        

        
            if(!filter_var($email, FILTER_VALIDATE_EMAIL)) 
            {
                   echo("invalid email format");
                    
                    if($result)  //checking email exits or not in database
                    {
                       echo("Email already exits");
                    }
                    
    
                    else
                    {
                        if($name != null && $email != null && $password != null && $dob != null)  //
                        {
                            if($request->hasfile($profile_image)) {
                                $simage=$request->file($profile_image);
                                $info = getimagesize($simage);
                        
                                if ($info['mime'] == 'image/jpeg') 
                                    $image_n = imagecreatefromjpeg($simage);
                        
                                elseif ($info['mime'] == 'image/gif') 
                                    $image_n = imagecreatefromgif($simage);
                        
                                elseif ($info['mime'] == 'image/png') 
                                    $image_n = imagecreatefrompng($simage);
                                    
                                $name =hexdec(uniqid());
                                imagejpeg($image_n, "public/store_product/".$name.".jpeg", 50);
                                
                                $data['image_stock_product']=$name.".jpeg";
                            }else{
                               $data['image_stock_product']=''; 
                            }
                            
                            
                            $insert_id = DB::table('stock_product')->insertGetId($data);
                            
                            if($request->hasfile('imageFile')) {
                                foreach($request->file('imageFile') as $image)
                                {
                                    $info = getimagesize($image);
                    
                                    if ($info['mime'] == 'image/jpeg') 
                                        $image_n = imagecreatefromjpeg($image);
                            
                                    elseif ($info['mime'] == 'image/gif') 
                                        $image_n = imagecreatefromgif($image);
                            
                                    elseif ($info['mime'] == 'image/png') 
                                        $image_n = imagecreatefrompng($image);
                                        
                                    $name =hexdec(uniqid());
                                    imagejpeg($image_n, "public/store_product/".$name.".jpeg", 50);
                                    
                                    $p_image = $name.".jpeg";
                                    
                                    $stock_product_picture = array(
                                        'product_id' => $insert_id,
                                        'picture' => $p_image
                                    );
                                    DB::table('stock_product_picture')->insert($stock_product_picture);
                                }
                            }
                            
    
                        }
                    }
                }
            }
            

  
    }

    

}