<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Signup</title>
    <link rel="icon" type="image/png" href="{{ asset('../admin/public/backend/dist/img/fav.png') }}"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="InfoLink is one of the leading broadband internet service provider (ISP) in Bangladesh. We offer quality internet solutions within affordable price." />
    <meta name="keywords" content="infolink limited, selfcare infolink">
    <meta name="author" content="Infolink Limited" />
    
    <link rel="stylesheet" href="../assets7/plugins/select2/css/select2.min.css">
    <link rel="stylesheet" type="text/css" href="../assets7/css/form_validation.css">
    <link rel="stylesheet" href="../assets7/css/style.css">
    <link rel="stylesheet" type="text/css" href="../assets7/js/js_calander/jquery-ui.css">
    <link href="{{ asset('../admin/public/backend/plugins/fileupload/css/bootstrap-fileupload.min.css') }}" rel="stylesheet" type="text/css" />
	<style type="text/css">
		/*national front*/
.pic-viewNational{
	margin-top: 10px;
	width:160px;
	
}
#rrightNational {
	margin-left: 30px;
	background: #2979ff;
	color: #fff;
	padding: 3px 15px;
	cursor: pointer;
	border-radius: 3px;
}
#rleftNational {
	
	background: #2979ff;
	color: #fff;
	padding: 3px 15px;
	cursor: pointer;
	border-radius: 3px;
}
/*national Back*/
.pic-viewbackNational{
	margin-top: 10px;
	width:160px;
}
#rrightbackNational {
	margin-left: 30px;
	background: #2979ff;
	color: #fff;
	padding: 3px 15px;
	cursor: pointer;
	border-radius: 3px;
}
#rleftbackNational {
	
	background: #2979ff;
	color: #fff;
	padding: 3px 15px;
	cursor: pointer;
	border-radius: 3px;
}
/*license front*/
.pic-viewlicense{
	margin-top: 10px;
	width:160px;
	
}
#rrightlicense {
	margin-left: 30px;
	background: #33beff;
	color: #fff;
	padding: 3px 15px;
	cursor: pointer;
	border-radius: 3px;
}
#rleftlicense {
	
	background: #33beff;
	color: #fff;
	padding: 3px 15px;
	cursor: pointer;
	border-radius: 3px;
}
/*license Back*/
.pic-viewbacklicense{
	margin-top: 10px;
	width:160px;
}
#rrightbacklicense {
	margin-left: 30px;
	background: #2979ff;
	color: #fff;
	padding: 3px 15px;
	cursor: pointer;
	border-radius: 3px;
}
#rleftbacklicense {
	
	background: #2979ff;
	color: #fff;
	padding: 3px 15px;
	cursor: pointer;
	border-radius: 3px;
}
/*passport*/
.pic-viewpassport{
	margin-top: 10px;
	width:160px;
	
}
#rrightpassport {
	margin-left: 30px;
	background: #2979ff;
	color: #fff;
	padding: 3px 15px;
	cursor: pointer;
	border-radius: 3px;
}
#rleftpassport {
	
	background: #2979ff;
	color: #fff;
	padding: 3px 15px;
	cursor: pointer;
	border-radius: 3px;
}
/*birth*/
.pic-viewbirth{
	margin-top: 10px;
	width:160px;
}
#rrightbirth{
	margin-left: 30px;
	background: #2979ff;
	color: #fff;
	padding: 3px 15px;
	cursor: pointer;
	border-radius: 3px;
}
#rleftbirth {
	background: #2979ff;
	color: #fff;
	padding: 3px 15px;
	cursor: pointer;
	border-radius: 3px;
}
.input-group{
    background:none;
}
	.datepicker>.datepicker-days {
		display: block;
	}
F
	ol.linenums {
		margin: 0 0 0 -8px;
	}
	
    .center-text {
      text-align: center;
    }

 .pic-view {
	margin-top: 10px;
	width:160px;
}

#rright {
	margin-left: 30px;
	background: #2979ff;
	color: #fff;
	padding: 3px 15px;
	cursor: pointer;
	border-radius: 3px;
}
#rleft {
	
	background: #2979ff;
	color: #fff;
	padding: 3px 15px;
	cursor: pointer;
	border-radius: 3px;
}
.profile-pic {
  position: relative;
  height:160px;
  border:1px solid #000;
}
.file-upload {
  display: none;
}

img {
    max-width: 100%;
    height: auto;
}
.upload-button {
  font-size: 1.2em;
}

.profile{position: relative; margin-left:70px;}
.p-image {
  position: absolute;
  top: 14%;
  right: 50%;
  background: #000;
  color: #fff;
  border-radius: 20px;
  border: 2px solid #fff;
  height: 30px;
  width: 30px;
  text-align: center;
  line-height: 23px;
}
.input-group {
    background: none;
}
    .use:disabled{
        opacity: .2;
    }
    .use {
        background: #132448;
        border: none;
        cursor: pointer;
        color: #fff;
        padding:5px 70px;
        border-radius:3px;
    }  
   .id-pic {
  position: relative;
 
 height:171px;
  border: 8px solid rgba(255, 255, 255, 0.7);
  
  margin-bottom: 40px;
}
.id-upload {
  display: none;
}


.id-button {
  font-size: 1.2em;
}

.id{position: relative; width: 100%;}
.id-image {
  position: absolute;
  top: 10%;
  right: 40%;
  background: #000;
  color: #fff;
  border-radius: 20px;
  border: 2px solid #fff;
  height: 30px;
  width: 30px;
  text-align: center;
  line-height: 23px;
}
.id-image:hover {
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
}
.id-button:hover {
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
  color: #999;
} 
   .back-pic {
  position: relative;
 
  height: 171px;
  border: 8px solid rgba(255, 255, 255, 0.7);
  
  margin-bottom: 40px;
}
.back-upload {
  display: none;
}
.back-button {
  font-size: 1.2em;
}
.card {
  /*box-shadow: 0 8px 16px 0 rgba(0,0,0,0.8);*/
}
.back{position: relative; width: 100%;}
.back-image {
  position: absolute;
  top: 10%;
  right: 40%;
  background: #000;
  color: #fff;
  border-radius: 20px;
  border: 2px solid #fff;
  height: 30px;
  width: 30px;
  text-align: center;
  line-height: 23px;
}
.back-image:hover {
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
}
.back-button:hover {
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
  color: #999;
}
.progressbar {
      counter-reset: step;
      padding: 0;

    }
    .progressbar li {
      list-style: none;
      display: inline-block;
      width: 15%;
      position: relative;
      text-align: center;
      cursor: pointer;
      z-index: 9;
    }
    .progressbar li:before {
      content: counter(step);
      counter-increment: step;
      width: 25px;
      height: 25px;
      line-height : 25px;
      border: 1px solid #ddd;
      border-radius: 100%;
      display: block;
      text-align: center;
      margin: 0 auto 10px auto;
      background-color: #fff;
    }
    .progressbar li:after {
      content: "";
      position: absolute;
      width: 100%;
      height: 1px;
      background-color: #ddd;
      top: 12px;
      right: 43%;
      z-index : -1;
    }
    
    .progressbar li:first-child:after {
      content: none;
    }
    .progressbar li.active {
      color: #2979ff;
    }
    .progressbar li.active::before {
    background: #2979ff;
    color: #fff;
    line-height: 21px;
    border: 1px solid #2979ff;
    font-weight: 600;
} 
    .progressbar li.active + li:after {
      background-color: #2979ff;
    }
    </style>

     <div class="pcoded-wrapper">
    <div class="pcoded-content">
        <div class="pcoded-inner-content">
                    <div class="main-body">
                        <div class="page-wrapper"> 
                         <div class="row">
                             <div class="col-md-2">
                                 &nbsp;
                             </div>
                             <div class="col-md-8">
                                 <div class="card">
                                     <form action="{{URL::to('client_sign_up')}}" method="post" enctype="multipart/form-data">
                                         @csrf
                                     <div class="card-block">
                                        <div class="wrap-input100" style=" border-bottom: 0; text-align:center;">
                                        <a href="{{url('/')}}"><img src="{{asset('assets7/images/logo.png')}}"></a>
                                    </div>
                                    <br>
                                    <div class="wrap-input100" style=" border-bottom: 0; text-align:center;">
                                        <h5>Please complete your profile</h5>
                                                <div class="pro">
                              <ul class="progressbar">
                                  <li class="active"></li>
                                  <li class="active"></li>
                                  <li></li>
                                  
                              </ul>
                          	</div>
                                    </div>
                                    <br>
                                    
                					   <div class="row">
                                     <div class="col-md-6">   
                                     
                                        
                                        <!--<div class="profile">
                                            <img class="profile-pic upload-button" srsets/images/user/Asset8.png" class="img-radius" alt="User-Profile-Image">
                                            <div class="p-image">
                                      <i class="feather icon-edit upload-button"></i>
                                        <input style="display: none;" name="profile_pic" class="file-upload" type="file" accept="image/jpeg, image/png" required/>
                                       </div>
                                           </div>-->
                                          
                                        <div class=" validate-input" data-validate="*">
                                            <span style="float: left;">Full Name <sup style="color:red">*</sup></span>
                                            <input class="input100 form-control" type="text"  name="name" id="name" placeholder="Full Name" required>
                                            <span class="focus-input100"></span>
                                        </div><br>
                    					          <div class=" validate-input" data-validate="*">
                                            <span style="float: left;">Email <sup style="color:red">*</sup></span>
                                            <input  class="input100 form-control" type="email" id="email" name="email" placeholder="Enter Your Email" required>
                                            <span class="focus-input100"></span>
                                        </div><br>
                                        <div class=" validate-input" data-validate="*">
                                             <span style="float: left;">Date of Birth <sup style="color:red">*</sup></span>
                                             <input type="text" id="datepicker" name="dob" class="input100 form-control" placeholder="dd-mm-yy" required />
                                              <span class="focus-input100"></span>
                                        </div><br>
                                        <!--<br>
                                        <h5><center>Address</center></h5>
                                        <div class=" validate-input" data-validate="*">
                                             <span>House, Flat, Building Name <sup style="color:red">*</sup></span>
                                                <div class=" validate-input" data-validate="*">
                                                  <input type="text" name="house" class="input100 form-control" placeholder="House, Flat, Building Name" required>
                                                  <span class="focus-input100"></span>
                                                </div>
                                          </div>
                                          <div class=" validate-input" data-validate="*">
                                            <span>Road, Block, Area <sup style="color:red">*</sup></span>
                                              <div class=" validate-input" data-validate="*">
                                                <input type="text" name="road" id="road" class="input100 form-control" placeholder="Road, Block, Area" required>
                                                <span class="focus-input100"></span>
                                              </div>
                        
                                          </div>
                                          <div class=" validate-input" data-validate="*">
                                            <span>District <sup style="color:red">*</sup></span>
                                                <div class=" validate-input" data-validate="*">
                                                    <input type="text" name="district" class="input100 form-control"  placeholder="District" required>
                                                    <span class="focus-input100"></span>
                                                </div>
                                          </div>
                                          <div class=" validate-input" data-validate="*">
                                            <span>Police Station <sup style="color:red">*</sup></span>
                                            <div class=" validate-input" data-validate="*">
                                              <input type="text" name="police_station" class="input100 form-control" placeholder="Police Station" required>
                                              <span class="focus-input100"></span>
                                            </div>
                        
                                          </div>
                                          <div class=" validate-input" data-validate="*">
                                            <span>Post Office <sup style="color:red">*</sup></span>
                                            <div class=" validate-input" >
                                                <input type="text" name="post_office" class="input100 form-control"  placeholder="Post Office" required>
                                                <span class="focus-input100"></span>
                                            </div>
                                          </div>
                                          <div class=" validate-input" data-validate="*">
                                            <span>Post Code <sup style="color:red">*</sup></span>
                                              <div class=" validate-input" >
                                                <input type="text" name="post_code" class="input100 form-control"  placeholder="Post Code" required>
                                                <span class="focus-input100"></span>
                                              </div>
                                          </div>-->
                                     
                                        </div>
            <div class="col-md-6">
            
            <span style="float: left;">Upload Profile Image <sup style="color:red">*</sup></span>
            <input type="file" class="form-control" name="file" id="file" required/> <br>
            <input type="hidden" name="rotation" id="rotation" value="0"/>
            <div class="img-preview" style="display: none;">
            <span id="rright">Rotate <i class="feather icon-rotate-ccw"></i></span>
            <span id="rleft">Rotate <i class="feather icon-rotate-cw"></i></span>
            <br>
            <div id="imgPreview">
                                                
            </div>
            </div>
            
            
             
							
            
            
            
            <span style="float: left;">Upload Your Identity <sup style="color:red">*</sup></span>
            <div class="input-group mb-3">
              <select class="form-control" id="identity_type" name="identity_type" onChange="getIdentity(this.value)" >
                <option selected disabled hidden value="">Select</option>
                <option value="1">National ID</option>
                <option value="2">Passport</option>
                <option value="3">Birth Certificate</option>
                <option value="4">Driving License </option>
              </select>
            </div>
            <div class="input-group mb-3">
                <div class="d_active d_active_1" style="display:none;">
               <div class=" validate-input" data-validate="*" id="">
                    <input type="text" name="identity_info"  class="input100 form-control" placeholder="Enter National ID" value="" >
                  <span class="focus-input100"></span>
                  </div>
                 &nbsp;
                 
                 <span style="float: left;">Upload National ID Front Side:</span><br><br>
                    <input type="file" class="form-control" name="fileNational" id="fileNational" /> <br>
                    <input type="hidden" name="rotationNational" id="rotationNational" value="0"/>
                    <div class="img-previewNational" style="display:none">
                        <span id="rleftNational">Rotate <i class="feather icon-rotate-cw"></i></span>
                        <span id="rrightNational">Rotate <i class="feather icon-rotate-ccw"></i></span>
                        <br>
                        <div id="imgPreviewNational">
                            
                        </div>
                    </div>
                 &nbsp;
                 <span style="float: left;">Upload National ID Back Side:</span><br><br>
                    <input type="file" class="form-control" name="filebackNational" id="filebackNational" /> <br>
                    <input type="hidden" name="rotationbackNational" id="rotationbackNational" value="0"/>
                    <div class="img-previewbackNational" style="display:none">
                        <span id="rleftbackNational">Rotate <i class="feather icon-rotate-cw"></i></span>
                        <span id="rrightbackNational">Rotate <i class="feather icon-rotate-ccw"></i></span>
                        <br>
                        <div id="imgPreviewbackNational">
                            
                        </div>
                    </div>
                </div>
                 <div class="d_active d_active_2" style="display:none;">
                 <span style="float: left;">Upload Passport Information Page:</span><br><br>
                    <input type="file" class="form-control" name="filepassport" id="filepassport" /> <br>
                    <input type="hidden" name="rotationpassport" id="rotationpassport" value="0"/>
                    <div class="img-previewpassport" style="display:none">
                        <span id="rleftpassport">Rotate <i class="feather icon-rotate-cw"></i></span>
                        <span id="rrightpassport">Rotate <i class="feather icon-rotate-ccw"></i></span>
                        <br>
                        <div id="imgPreviewpassport">
                            
                        </div>
                    </div>
                 
                </div>
                 <div class="d_active d_active_3" style="display:none;">
                 <span style="float: left;">Upload your Birth Certificate</span><br><br>
                    <input type="file" class="form-control" name="filebirth" id="filebirth" /> <br>
                    <input type="hidden" name="rotationbirth" id="rotationbirth" value="0"/>
                    <div class="img-previewbirth" style="display:none">
                        <span id="rleftbirth">Rotate <i class="feather icon-rotate-cw"></i></span>
                        <span id="rrightbirth">Rotate <i class="feather icon-rotate-ccw"></i></span>
                        <br>
                        <div id="imgPreviewbirth"> 
                        </div>
                    </div>
                </div>
                 <div class="d_active d_active_4" style="display:none;">
                 <span style="float: left;">Upload  Driving License Front Side:</span><br><br>
                    <input type="file" class="form-control" name="filelicense" id="filelicense" /> <br>
                    <input type="hidden" name="rotationlicense" id="rotationlicense" value="0"/>
                    <div class="img-previewlicense" style="display:none">
                        <span id="rleftlicense">Rotate <i class="feather icon-rotate-cw"></i></span>
                        <span id="rrightlicense">Rotate <i class="feather icon-rotate-ccw"></i></span>
                        <br>
                        <div id="imgPreviewlicense">
                            
                        </div>
                    </div>
                 &nbsp;
                 <span style="float: left;">Upload Driving License Back Side:</span><br><br>
                    <input type="file" class="form-control" name="filebacklicense" id="filebacklicense" /> <br>
                    <input type="hidden" name="rotationbacklicense" id="rotationbacklicense" value="0"/>
                    <div class="img-previewbacklicense" style="display:none">
                        <span id="rleftbacklicense">Rotate <i class="feather icon-rotate-cw"></i></span>
                        <span id="rrightbacklicense">Rotate <i class="feather icon-rotate-ccw"></i></span>
                        <br>
                        <div id="imgPreviewbacklicense">
                            
                        </div>
                    </div>
                </div>   
            </div>
                                         </div>
                                     </div><!--
                                     <br>
                                     <h5><center>Address</center></h5>
                                     <hr>
                                     
                                      <div class="row">
                                          <div class="col-md-4">
                                             <span>House, Flat, Building Name</span>
                                                <div class="wrap-input100 validate-input" data-validate="*">
                                                  <input type="text" name="house" class="input100 form-control" placeholder="House, Flat, Building Name" required>
                                                  <span class="focus-input100"></span>
                                                </div>
                                          </div>
                                          <div class="col-md-4">
                                            <span>Road, Block, Area</span>
                                              <div class="wrap-input100 validate-input" data-validate="*">
                                                <input type="text" name="road" id="road" class="input100 form-control" placeholder="Road, Block, Area" required>
                                                <span class="focus-input100"></span>
                                              </div>
                        
                                          </div>
                                          <div class="col-md-4">
                                            <span>District</span>
                                                <div class="wrap-input100 validate-input" data-validate="*">
                                                    <input type="text" name="district" class="input100 form-control"  placeholder="District" required>
                                                    <span class="focus-input100"></span>
                                                </div>
                                          </div>
                                          <div class="col-md-4">
                                            <span>Police Station</span>
                                            <div class="wrap-input100 validate-input" data-validate="*">
                                              <input type="text" name="police_station" class="input100 form-control" placeholder="Police Station" required>
                                              <span class="focus-input100"></span>
                                            </div>
                        
                                          </div>
                                          <div class="col-md-4">
                                            <span>Post Office</span>
                                            <div class="wrap-input100 validate-input" >
                                                <input type="text" name="post_office" class="input100 form-control"  placeholder="Post Office">
                                                <span class="focus-input100"></span>
                                            </div>
                                          </div>
                                          <div class="col-md-4">
                                            <span>Post Code</span>
                                              <div class="wrap-input100 validate-input" >
                                                <input type="text" name="post_code" class="input100 form-control"  placeholder="Post Code">
                                                <span class="focus-input100"></span>
                                              </div>
                                          </div>
                                          
                                          
                                      </div> -->
                                      <br>
                                      <div class="wrap-input100 validate-input" style="border-bottom:0px;">
                                             <center><span>Continue to accept <a style="text-decoration: underline; color: #000;" href="https://newsite.infolinkbd.com/client_page/terms_and_condition/" target="_blank">Terms & Conditions</a>  and <a style="text-decoration: underline; color: #000;" href="https://newsite.infolinkbd.com/client_page/privacy_policy/" target="_blank">Privacy Policy </a> of InfoLink LTD.</span></center>
                                        </div>
                                            <center> <div class="checkbox checkbox-fill d-inline">
                                               <input type="checkbox" name="checkbox_fill_1"  value="1" id="checkbox-fill-a1"> 
                                               <!-- name changed in this section -->
                                                <label for="checkbox-fill-a1" class="cr"> I Accept Terms & Conditions</label>
                                            </div></center>
                                            <div class="wrap-input100" style=" border-bottom: 0;">
                                            <center><input type="submit" id="submit"   name="submit" class="use" value="Next"></center>
                                        </div>
                                    </div>          
                                    </form>
                                     	
                                 </div>
                                
                             </div>
                             <div class="col-md-2">
                                 &nbsp;
                             </div>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="{{asset('assets7/js/jquery-3.2.1.min.js')}}"></script>
    <script src="{{asset('assets7/js/form_validation.js')}}"></script>
    <script src="{{asset('assets7/js/js_calander/jquery-ui.js')}}"></script>
    
    <script src="{{asset('assets7/plugins/select2/js/select2.full.min.js')}}"></script>
<!-- form-select-custom Js -->
<script src="{{asset('js/form-select-custom.js')}}"></script>
<script>
    $(function() {
    var rotation = 0;
    $("#rright").click(function() {
        rotation = (rotation -90) % 360;
        $(".pic-view").css({'transform': 'rotate('+rotation+'deg)'});
		
        if(rotation != 0){
            $(".pic-view").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }else{
            $(".pic-view").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }
        $('#rotation').val(rotation);
    });
	
    $("#rleft").click(function() {
        rotation = (rotation + 90) % 360;
        $(".pic-view").css({'transform': 'rotate('+rotation+'deg)'});
		
        if(rotation != 0){
            $(".pic-view").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }else{
            $(".pic-view").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }
        $('#rotation').val(rotation);
    });
});
$("#file").change(function (){
    // Image preview
    filePreview(this);
});
function filePreview(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#imgPreview + img').remove();
            $('#imgPreview').after('<img src="'+e.target.result+'" class="pic-view" />');
        };
        reader.readAsDataURL(input.files[0]);
        $('.img-preview').show();
    }else{
        $('#imgPreview + img').remove();
        $('.img-preview').hide();
    }
}
</script>
<script>
    $(function() {
    var rotation = 0;
    $("#rrightNational").click(function() {
        rotation = (rotation -90) % 360;
        $(".pic-viewNational").css({'transform': 'rotate('+rotation+'deg)'});
		
        if(rotation != 0){
            $(".pic-viewNational").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }else{
            $(".pic-viewNational").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }
        $('#rotationNational').val(rotation);
    });
	
    $("#rleftNational").click(function() {
        rotation = (rotation + 90) % 360;
        $(".pic-viewNational").css({'transform': 'rotate('+rotation+'deg)'});
		
        if(rotation != 0){
            $(".pic-viewNational").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }else{
            $(".pic-viewNational").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }
        $('#rotationNational').val(rotation);
    });
});
$("#fileNational").change(function (){
    // Image preview
    filePreviewNational(this);
});
function filePreviewNational(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#imgPreviewNational + img').remove();
            $('#imgPreviewNational').after('<img src="'+e.target.result+'" class="pic-viewNational" />');
        };
        reader.readAsDataURL(input.files[0]);
        $('.img-previewNational').show();
    }else{
        $('#imgPreviewNational + img').remove();
        $('.img-previewNational').hide();
    }
}
</script> 
<script>
    $(function() {
    var rotation = 0;
    $("#rrightbackNational").click(function() {
        rotation = (rotation -90) % 360;
        $(".pic-viewbackNational").css({'transform': 'rotate('+rotation+'deg)'});
		
        if(rotation != 0){
            $(".pic-viewbackNational").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }else{
            $(".pic-viewbackNational").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }
        $('#rotationbackNational').val(rotation);
    });
	
    $("#rleftbackNational").click(function() {
        rotation = (rotation + 90) % 360;
        $(".pic-viewbackNational").css({'transform': 'rotate('+rotation+'deg)'});
		
        if(rotation != 0){
            $(".pic-viewbackNational").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }else{
            $(".pic-viewbackNational").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }
        $('#rotationbackNational').val(rotation);
    });
});
$("#filebackNational").change(function (){
    // Image preview
    filePreviewbackNational(this);
});
function filePreviewbackNational(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#imgPreviewbackNational + img').remove();
            $('#imgPreviewbackNational').after('<img src="'+e.target.result+'" class="pic-viewbackNational" />');
        };
        reader.readAsDataURL(input.files[0]);
        $('.img-previewbackNational').show();
    }else{
        $('#imgPreviewbackNational + img').remove();
        $('.img-previewbackNational').hide();
    }
}
</script>
<!--passport-->
<script>
    $(function() {
    var rotation = 0;
    $("#rrightpassport").click(function() {
        rotation = (rotation -90) % 360;
        $(".pic-viewpassport").css({'transform': 'rotate('+rotation+'deg)'});
		
        if(rotation != 0){
            $(".pic-viewpassport").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }else{
            $(".pic-viewpassport").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }
        $('#rotationpassport').val(rotation);
    });
	
    $("#rleftpassport").click(function() {
        rotation = (rotation + 90) % 360;
        $(".pic-viewpassport").css({'transform': 'rotate('+rotation+'deg)'});
		
        if(rotation != 0){
            $(".pic-viewpassport").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }else{
            $(".pic-viewpassport").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }
        $('#rotationpassport').val(rotation);
    });
});
$("#filepassport").change(function (){
    // Image preview
    filepassport(this);
});
function filepassport(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#imgPreviewpassport + img').remove();
            $('#imgPreviewpassport').after('<img src="'+e.target.result+'" class="pic-viewpassport" />');
        };
        reader.readAsDataURL(input.files[0]);
        $('.img-previewpassport').show();
    }else{
        $('#imgPreviewpassport + img').remove();
        $('.img-previewpassport').hide();
    }
}
</script>
<!--Birth-->
<script>
    $(function() {
    var rotation = 0;
    $("#rrightbirth").click(function() {
        rotation = (rotation -90) % 360;
        $(".pic-viewbirth").css({'transform': 'rotate('+rotation+'deg)'});
		
        if(rotation != 0){
            $(".pic-viewbirth").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }else{
            $(".pic-viewbirth").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }
        $('#rotationbirth').val(rotation);
    });
	
    $("#rleftbirth").click(function() {
        rotation = (rotation + 90) % 360;
        $(".pic-viewbirth").css({'transform': 'rotate('+rotation+'deg)'});
		
        if(rotation != 0){
            $(".pic-viewbirth").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }else{
            $(".pic-viewbirth").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }
        $('#rotationbirth').val(rotation);
    });
});
$("#filebirth").change(function (){
    // Image preview
    filebirth(this);
});
function filebirth(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#imgPreviewbirth + img').remove();
            $('#imgPreviewbirth').after('<img src="'+e.target.result+'" class="pic-viewbirth" />');
        };
        reader.readAsDataURL(input.files[0]);
        $('.img-previewbirth').show();
    }else{
        $('#imgPreviewbirth + img').remove();
        $('.img-previewbirth').hide();
    }
}
</script>
<!--license-->
<script>
    $(function() {
    var rotation = 0;
    $("#rrightlicense").click(function() {
        rotation = (rotation -90) % 360;
        $(".pic-viewlicense").css({'transform': 'rotate('+rotation+'deg)'});
		
        if(rotation != 0){
            $(".pic-viewlicense").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }else{
            $(".pic-viewlicense").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }
        $('#rotationlicense').val(rotation);
    });
	
    $("#rleftlicense").click(function() {
        rotation = (rotation + 90) % 360;
        $(".pic-viewlicense").css({'transform': 'rotate('+rotation+'deg)'});
		
        if(rotation != 0){
            $(".pic-viewlicense").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }else{
            $(".pic-viewlicense").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }
        $('#rotationlicense').val(rotation);
    });
});
$("#filelicense").change(function (){
    // Image preview
    filePreviewlicense(this);
});
function filePreviewlicense(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#imgPreviewlicense + img').remove();
            $('#imgPreviewlicense').after('<img src="'+e.target.result+'" class="pic-viewlicense" />');
        };
        reader.readAsDataURL(input.files[0]);
        $('.img-previewlicense').show();
    }else{
        $('#imgPreviewlicense + img').remove();
        $('.img-previewlicense').hide();
    }
}
</script> 
<script>
    $(function() {
    var rotation = 0;
    $("#rrightbacklicense").click(function() {
        rotation = (rotation -90) % 360;
        $(".pic-viewbacklicense").css({'transform': 'rotate('+rotation+'deg)'});
		
        if(rotation != 0){
            $(".pic-viewbacklicense").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }else{
            $(".pic-viewbacklicense").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }
        $('#rotationbackNational').val(rotation);
    });
	
    $("#rleftbacklicense").click(function() {
        rotation = (rotation + 90) % 360;
        $(".pic-viewbacklicense").css({'transform': 'rotate('+rotation+'deg)'});
		
        if(rotation != 0){
            $(".pic-viewbacklicense").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }else{
            $(".pic-viewbacklicense").css({'max-width':'160px','margin-top':'40px','margin-bottom':'40px'});
        }
        $('#rotationbacklicense').val(rotation);
    });
});
$("#filebacklicense").change(function (){
    // Image preview
    filePreviewbacklicense(this);
});
function filePreviewbacklicense(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#imgPreviewbacklicense + img').remove();
            $('#imgPreviewbacklicense').after('<img src="'+e.target.result+'" class="pic-viewbacklicense" />');
        };
        reader.readAsDataURL(input.files[0]);
        $('.img-previewbacklicense').show();
    }else{
        $('#imgPreviewbacklicense + img').remove();
        $('.img-previewbacklicense').hide();
    }
}
</script>
<script type="text/javascript">
    $(function() {
		$("#identity_type").on('change',function(){
			var valu = $(this).val();
			$(".d_active").slideUp('fast');
			$(".d_active_"+valu).slideDown();
		});
    });
</script>
<script type="text/javascript">
    $(document).ready(
    function(){
      $('input:file').change(
        function(){
            if ($(this).val()) {
                $('input:submit').attr('disabled',false); 
            } 
        }
      );
       $(function() {
    $("#datepicker").datepicker({
      changeMonth: true,
      changeYear: true,
      minDate: '-100y',
      maxDate: '-13y',
      dateFormat: "dd-mm-yy"
    });
    }); 
    });
  </script>
	<script type="text/javascript">
	  $(document).ready(function() {
		var readURL = function(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				reader.onload = function (e) {
					$('.profile-pic').attr('src', e.target.result);
				}
				reader.readAsDataURL(input.files[0]);
			}
		}
		$(".file-upload").on('change', function(){
			readURL(this);
		});
		$(".upload-button").on('click', function() {
		   $(".file-upload").click();
		});
	});
	</script>
	<script type="text/javascript">
	  $(document).ready(function() {
		var readURL = function(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				reader.onload = function (e) {
					$('.id-pic').attr('src', e.target.result);
				}
				reader.readAsDataURL(input.files[0]);
			}
		}
		$(".id-upload").on('change', function(){
			readURL(this);
		});
		$(".id-button").on('click', function() {
		   $(".id-upload").click();
		});
		
	});
	</script>
	<script type="text/javascript">
	  $(document).ready(function() {
	var readURL = function(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				reader.onload = function (e) {
					$('.back-pic').attr('src', e.target.result);
				}
				reader.readAsDataURL(input.files[0]);
			}
		}
		$(".back-upload").on('change', function(){
			readURL(this);
		});
		$(".back-button").on('click', function() {
		   $(".back-upload").click();
		});
		
	});
	</script>
	<script type="text/javascript">
	function getIdentity(){
        var xmlhttp;
        if (window.XMLHttpRequest){
          xmlhttp=new XMLHttpRequest();
        }else{
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        if(window.XMLHttpRequest){
          xmlhttp = new XMLHttpRequest();
        }else{
          xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function(){
          if(xmlhttp.readyState==4 ){
              document.getElementById("identity_info").innerHTML=xmlhttp.responseText;
            }
        }
        var id = document.getElementById("identity_type").value;
      xmlhttp.open("GET","getIdentityInfo?id=" + id,true);
      xmlhttp.send();
    }
	</script>
	<script src="{{ asset('public/backend/plugins/fileupload/js/bootstrap-fileupload.min.js') }}"></script>