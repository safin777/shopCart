<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use DB;
use App\User;
use App\Http\Requests;
use Session;
use Mail;
use Toastr;


class ClientSignupController extends Controller
{
    public function signup(Request $request)
    {
        $title="Signup";
        return view('signup.signup',compact('title'));
        
    }


    public function viewSignUp()
    {
        return view('signup');
    }


    public function SignUpValidation(Request $request) 
    {
        
        $name= $request->name;
        $email= $request->email;
        $password= $request->password;
        $dob= $request->dob;
        $profile_image= $request->file;

        $identity_type = $request->identity_type;

        //  national id image upload
        $national_id_number = $request->identity_info;
        $national_id_front = $request->fileNational;
        $national_id_back = $request->filebackNational;

        //passport image

        $passport_image = $request->filepassport;

        //birth certificate

        $birth_certificate_info = $request->filebirth;

        //driving license
        $driving_license_front= $request->filelicense;
        $driving_license_back= $request->filebacklicense;

        // checkbox 

        $accept_terms = $request->checkbox_fill_1;

        $result=DB::table('client')
                ->where('email',$email)
                ->first();


        $data_with_nid=array(); 
		$data_with_nid['client_username']=$request->name;
		$data_with_nid['client_email1']=$request->email;
		$data_with_nid['client_password']=$request->password;
		$data_with_nid['client_dob']=$request->dob;
		$data_with_nid['identification_type']=$request->identity_type;
		$data_with_nid['client_national_id']=$request->identity_info;
        $data_with_nid['identification_image']=$nid_front_image;
        $data_with_nid['identity_back']=$nid_back_image;
        $data_with_nid['client_image']=$p_image;


        $data_with_passport=array(); 
		$data_with_passport['client_username']=$request->name;
		$data_with_passport['client_email1']=$request->email;
		$data_with_passport['client_password']=$request->password;
		$data_with_passport['client_dob']=$request->dob;
		$data_with_passport['identification_type']=$request->identity_type;
		$data_with_passport['identification_image']=$passport_image;
        $data_with_passport['client_image']=$p_image;


        $data_with_birth_certificate=array(); 
		$data_with_birth_certificate['client_username']=$request->name;
		$data_with_birth_certificate['client_email1']=$request->email;
		$data_with_birth_certificate['client_password']=$request->password;
		$data_with_birth_certificate['client_dob']=$request->dob;
		$data_with_birth_certificate['identification_type']=$request->identity_type;
		$data_with_birth_certificate['client_image']=$p_image;
        $data_with_birth_certificate['identification_image']=$birth_certificate_image;
        

        $data_with_driving_license=array(); 
		$data_with_driving_license['client_username']=$request->name;
		$data_with_driving_license['client_email1']=$request->email;
		$data_with_driving_license['client_password']=$request->password;
		$data_with_driving_license['client_dob']=$request->dob;
		$data_with_driving_license['identification_type']=$request->identity_type;
		$data_with_driving_license['client_image']=$p_image;
        $data_with_driving_license['identification_image']=$license_front_image;
        $data_with_driving_license['identity_back']= $license_back_image;

        
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)) 
        {
               echo("invalid email format");
                
                if($result)  //checking email exits or not in database
                {
                   echo("Email already exits");
                }


                else
                {
                   if($name != null && $email != null && $password != null && $dob != null)
                   {
                        if($request->hasfile('file')) 
                        {  //confused
                            foreach($request->file('file') as $image)
                            {
                                $info = getimagesize($image);
                
                                if ($info['mime'] == 'image/jpeg') 
                                    $image_n = imagecreatefromjpeg($image);
                        
                                elseif ($info['mime'] == 'image/gif') 
                                    $image_n = imagecreatefromgif($image);
                        
                                elseif ($info['mime'] == 'image/png') 
                                    $image_n = imagecreatefrompng($image);
                                    
                                    $image_name=hexdec(uniqid());
                                imagejpeg($image_n, "public/store_product/".$image_name.".jpeg",50); //change the path of the image folder 
                                
                                $p_image = $image_name.".jpeg";
                                
                                

                            // DB::table('stock_product_picture')->insert($stock_product_picture);
                            }


                                if($identity_type == 1)
                                {
                                    
                                    if($request->hasfile('fileNational')) 
                                        {  //confused
                                            foreach($request->file('fileNational') as $image)
                                            {
                                                $info = getimagesize($image);
                                
                                                if ($info['mime'] == 'image/jpeg') 
                                                    $image_n = imagecreatefromjpeg($image);
                                        
                                                elseif ($info['mime'] == 'image/gif') 
                                                    $image_n = imagecreatefromgif($image);
                                        
                                                elseif ($info['mime'] == 'image/png') 
                                                    $image_n = imagecreatefrompng($image);
                                                    
                                                    $image_name =hexdec(uniqid());
                                                imagejpeg($image_n, "public/store_product/".$image_name.".jpeg", 50); //change the path of the image folder 
                                                
                                                $nid_front_image = $image_name.".jpeg";
                                                
                                          
                                            }
                                            
                                            if($request->hasfile('filebackNational')) 
                                                {  //confused
                                                    foreach($request->file('file backNational') as $image)
                                                    {
                                                        $info = getimagesize($image);
                                        
                                                        if ($info['mime'] == 'image/jpeg') 
                                                            $image_n = imagecreatefromjpeg($image);
                                                
                                                        elseif ($info['mime'] == 'image/gif') 
                                                            $image_n = imagecreatefromgif($image);
                                                
                                                        elseif ($info['mime'] == 'image/png') 
                                                            $image_n = imagecreatefrompng($image);
                                                            
                                                            $image_name =hexdec(uniqid());
                                                        imagejpeg($image_n, "public/store_product/".$image_name.".jpeg", 50); //change the path of the image folder 
                                                        
                                                        $nid_back_image = $image_name.".jpeg";
                                                    
                            
                                                    }


                                                    if($request->checkbox_fill_1 == 1)
                                                    {
                                                        DB::table('client')->insert($data_with_nid);
                                                        echo("Profile created!");
                                                    }

                                                    else
                                                    {
                                                        echo("accept terms and condition!");
                                                    }
                                                }


                                        }    

                                    }

                                    else
                                    {
                                        echo("Please enter your NID");
                                    }
                                }



                                elseif($identity_type == 2)
                                {
                                    if($request->hasfile('filepassport')) 
                                    {  //confused
                                        foreach($request->file('filepassport') as $image)
                                        {
                                            $info = getimagesize($image);
                            
                                            if ($info['mime'] == 'image/jpeg') 
                                                $image_n = imagecreatefromjpeg($image);
                                    
                                            elseif ($info['mime'] == 'image/gif') 
                                                $image_n = imagecreatefromgif($image);
                                    
                                            elseif ($info['mime'] == 'image/png') 
                                                $image_n = imagecreatefrompng($image);
                                                
                                                $image_name =hexdec(uniqid());
                                            imagejpeg($image_n, "public/store_product/".$image_name.".jpeg", 50); //change the path of the image folder 
                                            
                                            $passport_image = $image_name.".jpeg";
                                            
                                            
                
                                        
                                        }

                                        if($request->checkbox_fill_1 == 1)
                                        {
                                            DB::table('client')->insert($data_with_passport);
                                            echo("Profile created!");
                                        }

                                        else
                                        {
                                            echo("accept terms and condition!");
                                        }
                                        
                                    }

                                    else
                                    {
                                        echo("Please enter your passport image");
                                    }
                                }

                                elseif($identity_type == 3)
                                {
                                    if($request->hasfile('filebirth')) 
                                    {  //confused
                                        foreach($request->file('filebirth') as $image)
                                        {
                                            $info = getimagesize($image);
                            
                                            if ($info['mime'] == 'image/jpeg') 
                                                $image_n = imagecreatefromjpeg($image);
                                    
                                            elseif ($info['mime'] == 'image/gif') 
                                                $image_n = imagecreatefromgif($image);
                                    
                                            elseif ($info['mime'] == 'image/png') 
                                                $image_n = imagecreatefrompng($image);
                                                
                                            $image_name =hexdec(uniqid());
                                            imagejpeg($image_n, "public/store_product/".$image_name.".jpeg", 50); //change the path of the image folder 
                                            
                                            $birth_certificate_image = $image_name.".jpeg";
                                            
                                            
                
                                        // DB::table('stock_product_picture')->insert($stock_product_picture);
                                        }

                                        if($request->checkbox_fill_1 == 1)
                                        {
                                            DB::table('client')->insert($data_with_birth_certificate);
                                            echo("Profile created!");
                                        }  

                                        else
                                        {
                                            echo("accept terms and condition!");
                                        }
                                    }


                                    else
                                    {
                                        echo("Please enter your Birth Certificate");
                                    }
                                }

                                elseif($identity_type == 4)
                                {
                                    if($request->hasfile('filelicense')) 
                                    {  //confused
                                        foreach($request->file('filelicense') as $image)
                                        {
                                            $info = getimagesize($image);
                            
                                            if ($info['mime'] == 'image/jpeg') 
                                                $image_n = imagecreatefromjpeg($image);
                                    
                                            elseif ($info['mime'] == 'image/gif') 
                                                $image_n = imagecreatefromgif($image);
                                    
                                            elseif ($info['mime'] == 'image/png') 
                                                $image_n = imagecreatefrompng($image);
                                                
                                            $image_name =hexdec(uniqid());
                                            imagejpeg($image_n, "public/store_product/".$image_name.".jpeg", 50); //change the path of the image folder 
                                            
                                            $license_front_image = $image_name.".jpeg";
             
                                        }
                                    
                                        if($request->hasfile('filebacklicense')) 
                                        {  
                                            foreach($request->file('filebacklicense') as $image)
                                            {
                                                $info = getimagesize($image);
                                
                                                if ($info['mime'] == 'image/jpeg') 
                                                    $image_n = imagecreatefromjpeg($image);
                                        
                                                elseif ($info['mime'] == 'image/gif') 
                                                    $image_n = imagecreatefromgif($image);
                                        
                                                elseif ($info['mime'] == 'image/png') 
                                                    $image_n = imagecreatefrompng($image);
                                                    
                                                $license_image =hexdec(uniqid());
                                                imagejpeg($image_n, "public/store_product/".$license_image.".jpeg", 50); //change the path of the image folder 
                                                
                                                $license_back_image = $license_image.".jpeg";
                                           
                                            }

                                            if($request->checkbox_fill_1 == 1)
                                            {
                                                DB::table('client')->insert($data_with_driving_license);
                                                echo("Profile created!"); 
                                            }

                                            else
                                            {
                                                echo("accept terms and condition!");
                                            }
                                        }

                                    }
                                        
                                    else
                                    {
                                        echo("Please enter your driving license information");
                                    }
                                }    
                                        




                        }
                    }   

                }
    }


}




    

