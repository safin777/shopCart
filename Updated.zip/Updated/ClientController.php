<?php 

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Permissions;
use DB;
use PDF;
use Session;

class ClientController extends Controller {
    
    protected $permissions;
    public $permission_val = 0;
    public $privillige_menu = array();
    
    function __construct(Permissions $permissions)
    {
        $this->permissions = $permissions;
        
        $this->middleware(function ($request, $next){
            $permission_type = Session::get('permission_type');
            $menu_permission = $this->permissions->has_permission('clients',$permission_type);
            if(!$menu_permission->isEmpty()){
                $menu_previllige = $this->permissions->has_previllige_permission($permission_type);
                $this->permission_val = $menu_permission[0]->permission_level;
                $this->privillige_menu = $menu_previllige;
                return $next($request);
            }else{
                //return abort(404);
                return redirect('/permission_denied');
            }
            
        });
    }
	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
	    $title = 'Client List';
        $active_menu = 'client';
        $current_menu = 'client_all';
   	    return view("client.index",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu]);
	}
	
	public function add(){
	    if($this->permission_val == 1){
            return redirect('/permission_denied');
        }
        $title = 'Add Client';
        $active_menu = 'client';
        $current_menu = 'client_all';
    	return view("client.add",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu]);
    }
	
	public function list()
	{
	    $title = 'Client List';
        $active_menu = 'client';
        $current_menu = 'client_list';
        $all_client = DB::table('client')->select('client_id','client_title')->get();
        $all_branch = DB::table('branch')->select('branch_id','branch_name')->get();
        $all_admin = DB::table('admin')->select('admin_id','user_name')->get();
	    
        $admin_branch = Session::get('admin_branch');
		if($admin_branch){
		   
			$branch_ids = array();
			foreach($admin_branch as $listItem) {
				$branch_ids[] = $listItem->branch_id;
			}
			if(in_array(0, $branch_ids)) {
			    $client_list = DB::table('client')
                            ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                            ->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name')
                            ->orderBy('client.client_id','DESC')
                            ->paginate(25);	
			}else{
			    $client_list = DB::table('client');
                $client_list = $client_list->join('branch', 'client.branch_id', '=', 'branch.branch_id');
                $client_list = $client_list->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name');
                foreach($branch_ids as $branch){
				    $client_list = $client_list->orWhere('client.branch_id',$branch);
				}
				$client_list = $client_list->orderBy('client.client_id','DESC');
                $client_list = $client_list->paginate(25);
			}
		}
   	    return view("client.list",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_list' => $client_list,'all_client'=>$all_client,'all_branch'=>$all_branch,'all_admin'=>$all_admin]);
	}
	
	public function search(Request $request)
	{
	    $title = 'Client List';
        $active_menu = 'client';
        $current_menu = 'client_list';
        $all_client = DB::table('client')->select('client_id','client_title')->get();
        $all_branch = DB::table('branch')->select('branch_id','branch_name')->get();
        $all_admin = DB::table('admin')->select('admin_id','user_name')->get();
        $q = $request->q;
         //$q = Request::get ( 'q' );
         if($q != ""){
            $data = DB::table('client')
                            ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                            ->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name')
                            ->where('client.client_title', '=', $q)
                            ->orderBy('client.client_id','DESC')
                            ->paginate(25)->setPath('');
            $data->appends ( array (
                                'q' => $q 
                            ) );
            return view("client.list",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_list' => $data,'all_client'=>$all_client,'all_branch'=>$all_branch,'all_admin'=>$all_admin]);
         }else{
            return redirect('/client_list');
         }
	}
	
	public function advance(Request $request)
    {
        $title = 'Client List';
        $active_menu = 'client';
        $current_menu = 'client_list';
        $all_client = DB::table('client')->select('client_id','client_title')->get();
        $all_branch = DB::table('branch')->select('branch_id','branch_name')->get();
        $all_admin = DB::table('admin')->select('admin_id','user_name')->get();
        $data = $request->all();
        /*if( $request->branch_id){
            $client_list = DB::table('client')
                        ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                        ->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name');
            $client_list = $client_list->where('client.branch_id',$request->branch_id);
            $client_list = $client_list->paginate(10);
        }*/
        
        $client_list = \DB::table('client')
                            ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                            ->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name');
        if( $request->client_id){
            $client_list = $client_list->where('client.client_id',$request->client_id);
        }
        if( $request->branch_id){
            $client_list = $client_list->where('client.branch_id',$request->branch_id);
        }
        if( $request->status){
            $client_list = $client_list->where('client.client_status',$request->status);
        }
        if( $request->reference_id){
            $client_list = $client_list->where('client.reference_by',1);
            $client_list = $client_list->where('client.reference_id',$request->reference_id);
        }
        if( $request->admin_id){
            $client_list = $client_list->where('client.admin_id',$request->admin_id);
        }
        
        $client_list = $client_list->paginate(10)->appends('branch_id',3);
        return view("client.search",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'all_client'=>$all_client,'all_branch'=>$all_branch,'all_admin'=>$all_admin,'client_list'=>$client_list,'sdata'=>$data]);
    }
	
	public function list_branch($id = NULL)
	{
	    $branch_id = base64_decode($id);
	    $branch_info = DB::table('branch')->where('branch_id',$branch_id)->first();
	    if($branch_info){
	        $branch = $branch_info->branch_name;
	    }else{
	        $branch = '';
	    }
	    $title = $branch.' Client List';
        $active_menu = 'client';
        $current_menu = 'client_list_'.$branch_id;
        $all_client = DB::table('client')->select('client_id','client_title')->get();
        $all_branch = DB::table('branch')->select('branch_id','branch_name')->get();
        $all_admin = DB::table('admin')->select('admin_id','user_name')->get();
        $client_list = DB::table('client')
                            ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                            ->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name')
                            ->where('client.branch_id',$branch_id)
                            ->orderBy('client.client_id','DESC')
                            ->paginate(25);
   	    return view("client.list",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_list' => $client_list,'all_client'=>$all_client,'all_branch'=>$all_branch,'all_admin'=>$all_admin]);
	}
	
	public function referral_list()
	{
	    $title = 'Referral Client List';
        $active_menu = 'client_referral';
        $current_menu = 'client_referral_list';
        $all_client = DB::table('client')->select('client_id','client_title')->get();
        $all_branch = DB::table('branch')->select('branch_id','branch_name')->get();
        $all_admin = DB::table('admin')->select('admin_id','user_name')->get();
        $referral_id = Session::get('admin_id');
        $client_list = DB::table('client')
                            ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                            ->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name')
                            ->where('client.reference_by',1)
                            ->where('client.reference_id',$referral_id)
                            ->orderBy('client.client_id','DESC')
                            ->paginate(25);
   	    return view("client.list",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_list' => $client_list,'all_client'=>$all_client,'all_branch'=>$all_branch,'all_admin'=>$all_admin]);
	}
	
	public function address()
	{
	    $title = 'Client Address List';
        $active_menu = 'client';
        $current_menu = 'client_address';
   	    return view("client.address",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu]);
	}
	
	public function active()
	{
	    $title = 'Active Client List';
        $active_menu = 'client';
        $current_menu = 'client_list_active';
        $all_client = DB::table('client')->select('client_id','client_title')->get();
        $all_branch = DB::table('branch')->select('branch_id','branch_name')->get();
        $all_admin = DB::table('admin')->select('admin_id','user_name')->get();
        
        $admin_branch = Session::get('admin_branch');
		if($admin_branch){
			$branch_ids = array();
			foreach($admin_branch as $listItem) {
				$branch_ids[] = $listItem->branch_id;
			}
			if(in_array(0, $branch_ids)) {
			    $client_list = DB::table('client')
                            ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                            ->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name')
                            ->where('client.client_status',1)
                            ->orderBy('client.client_id','DESC')
                            ->paginate(25);	
			}else{
			    $client_list = DB::table('client');
                $client_list = $client_list->join('branch', 'client.branch_id', '=', 'branch.branch_id');
                $client_list = $client_list->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name');
                foreach($branch_ids as $branch){
				    $client_list = $client_list->orWhere('client.branch_id',$branch);
				}
				$client_list = $client_list->where('client.client_status',1);
				$client_list = $client_list->orderBy('client.client_id','DESC');
                $client_list = $client_list->paginate(25);
			}
		}
   	    return view("client.list",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_list' => $client_list,'all_client'=>$all_client,'all_branch'=>$all_branch,'all_admin'=>$all_admin]);
	}
	
	public function referral_active()
	{
	    $title = 'Referral Active Client List';
        $active_menu = 'client_referral';
        $current_menu = 'client_referral_active';
        $all_client = DB::table('client')->select('client_id','client_title')->get();
        $all_branch = DB::table('branch')->select('branch_id','branch_name')->get();
        $all_admin = DB::table('admin')->select('admin_id','user_name')->get();
        $referral_id = Session::get('admin_id');
        //$referral_id = 145;
        $client_list = DB::table('client')
                            ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                            ->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name')
                            ->where('client.client_status',1)
                            ->where('client.reference_by',1)
                            ->where('client.reference_id',$referral_id)
                            ->orderBy('client.client_id','DESC')
                            ->paginate(25);
   	    return view("client.list",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_list' => $client_list,'all_client'=>$all_client,'all_branch'=>$all_branch,'all_admin'=>$all_admin]);
	}
	
	public function inactive()
	{
	    $title = 'Inactive Client List';
        $active_menu = 'client';
        $current_menu = 'client_list_inactive';
        $all_client = DB::table('client')->select('client_id','client_title')->get();
        $all_branch = DB::table('branch')->select('branch_id','branch_name')->get();
        $all_admin = DB::table('admin')->select('admin_id','user_name')->get();
        $admin_branch = Session::get('admin_branch');
		if($admin_branch){
			$branch_ids = array();
			foreach($admin_branch as $listItem) {
				$branch_ids[] = $listItem->branch_id;
			}
			if(in_array(0, $branch_ids)) {
			    $client_list = DB::table('client')
                            ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                            ->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name')
                            ->where('client.client_status',2)
                            ->orderBy('client.client_id','DESC')
                            ->paginate(25);	
			}else{
			    $client_list = DB::table('client');
                $client_list = $client_list->join('branch', 'client.branch_id', '=', 'branch.branch_id');
                $client_list = $client_list->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name');
                foreach($branch_ids as $branch){
				    $client_list = $client_list->orWhere('client.branch_id',$branch);
				}
				$client_list = $client_list->where('client.client_status',2);
				$client_list = $client_list->orderBy('client.client_id','DESC');
                $client_list = $client_list->paginate(25);
			}
		}
   	    return view("client.list",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_list' => $client_list,'all_client'=>$all_client,'all_branch'=>$all_branch,'all_admin'=>$all_admin]);
	}
	
	public function referral_inactive()
	{
	    $title = 'Referral Inactive Client List';
        $active_menu = 'client_referral';
        $current_menu = 'client_referral_inactive';
        $all_client = DB::table('client')->select('client_id','client_title')->get();
        $all_branch = DB::table('branch')->select('branch_id','branch_name')->get();
        $all_admin = DB::table('admin')->select('admin_id','user_name')->get();
        $referral_id = Session::get('admin_id');
        $client_list = DB::table('client')
                            ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                            ->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name')
                            ->where('client.client_status',2)
                            ->where('client.reference_by',1)
                            ->where('client.reference_id',$referral_id)
                            ->orderBy('client.client_id','DESC')
                            ->paginate(25);
   	    return view("client.list",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_list' => $client_list,'all_client'=>$all_client,'all_branch'=>$all_branch,'all_admin'=>$all_admin]);
	}
	
	public function vip()
	{
	    $title = 'VIP Client List';
        $active_menu = 'client';
        $current_menu = 'client_list_vip';
        $all_client = DB::table('client')->select('client_id','client_title')->get();
        $all_branch = DB::table('branch')->select('branch_id','branch_name')->get();
        $all_admin = DB::table('admin')->select('admin_id','user_name')->get();
        $client_list = DB::table('client')
                            ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                            ->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name')
                            ->where('client.is_vip_client',1)
                            ->orderBy('client.client_id','DESC')
                            ->paginate(25);
   	    return view("client.list",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_list' => $client_list,'all_client'=>$all_client,'all_branch'=>$all_branch,'all_admin'=>$all_admin]);
	}
	
	public function online()
	{
	    $title = 'Online Registration Client List';
        $active_menu = 'client';
        $current_menu = 'client_list_online';
        $all_client = DB::table('client')->select('client_id','client_title')->get();
        $all_branch = DB::table('branch')->select('branch_id','branch_name')->get();
        $all_admin = DB::table('admin')->select('admin_id','user_name')->get();
        $client_list = DB::table('client')
                            ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                            ->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name')
                            ->where('client.registration_type',1)
                            ->orderBy('client.client_id','DESC')
                            ->paginate(25);
   	    return view("client.list",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_list' => $client_list,'all_client'=>$all_client,'all_branch'=>$all_branch,'all_admin'=>$all_admin]);
	}
	
	public function need_printed_bill()
	{
	    $title = 'Need Printed Bill Client List';
        $active_menu = 'client';
        $current_menu = 'client_list_need_bill';
        
        $client_list = DB::table('client')
                            ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                            ->select('client.client_id', 'client.client_title','client.contact_person','client.is_vip_client','client.send_printed_bill','client.client_email1', 'client.client_email2', 'client.client_phone1','client.client_phone2','client.client_status','branch.branch_name')
                            ->where('client.send_printed_bill',1)
                            ->where('client.client_status',1)
                            ->orderBy('client.client_id','DESC')
                            ->get();
   	    return view("client.need_printed_bill",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_list' => $client_list]);
	}
	
	public function client_phone()
	{
	    $title = 'Client Phone List';
        $active_menu = 'client';
        $current_menu = 'client_phone';
   	    return view("client.client_phone",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu]);
	}
	
	public function client_email()
	{
	    $title = 'Client Email List';
        $active_menu = 'client';
        $current_menu = 'client_email';
   	    return view("client.client_email",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu]);
	}
	
	public function client_details($id=NULL)
	{
	    $title = 'Client Details';
        $active_menu = 'client';
        $current_menu = 'client_list';
        
        $client_id = base64_decode($id);
        if($client_id){
            
            $client_info = DB::table('client')
					        ->where('client_id',$client_id)
                            ->first();
            $invoice_info = DB::table('invoice')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            $invoice_recurring_info = DB::table('invoice_recurring')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            
            $connection_list = DB::table('connection_list')
                            ->join('connection_network_details', 'connection_network_details.connection_id','=','connection_list.connection_id')
                            ->select('connection_list.connection_id','connection_list.client_address_id','connection_list.client_id','connection_list.auto_disconnect','connection_list.device_id','connection_list.connection_address','connection_list.activation_date','connection_list.link_status','connection_network_details.ip_address')
                            ->where('connection_list.client_id',$client_id)
                            ->orderBy('connection_list.connection_id','DESC')
                            ->get();
            $task_list		= DB::table('task_list')->where('client_id',$client_id)->get();
    		$reference_by	= DB::table('client')->where(array('reference_by'=>2,'reference_id'=>$client_id))->get();
    		$address_list	= DB::table('client_address')->where('client_id',$client_id)->get();
            
            return view("client.client_details",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_info' => $client_info,'invoice_info' => $invoice_info,'invoice_recurring_info'=>$invoice_recurring_info,'connection_list'=>$connection_list,'task_list' => $task_list,'reference_by'=>$reference_by,'address_list'=>$address_list]);
        }else{
            redirect('client.list');
        }
	}
	
	public function bill_summary($id=NULL)
	{
	    $title = 'Bill Summary';
        $active_menu = 'client';
        $current_menu = 'client_list';
        
        $client_id = base64_decode($id);
        if($client_id){
								   
            $client_info = DB::table('client')
					        ->where('client_id',$client_id)
                            ->first();
            $invoice_info = DB::table('invoice')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            $invoice_recurring_info = DB::table('invoice_recurring')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            
            $connection_list = DB::table('connection_list')
                            ->join('connection_network_details', 'connection_network_details.connection_id','=','connection_list.connection_id')
                            ->select('connection_list.connection_id','connection_list.client_address_id','connection_list.client_id','connection_list.auto_disconnect','connection_list.device_id','connection_list.connection_address','connection_list.activation_date','connection_list.link_status','connection_network_details.ip_address')
                            ->where('connection_list.client_id',$client_id)
                            ->orderBy('connection_list.connection_id','DESC')
                            ->get();
            $task_list		= DB::table('task_list')->where('client_id',$client_id)->get();
    		$reference_by	= DB::table('client')->where(array('reference_by'=>2,'reference_id'=>$client_id))->get();
    		$address_list	= DB::table('client_address')->where('client_id',$client_id)->get();
    		
            $bill_summery	= $this->list_summery_payment($client_id);
            $unmaped		= $this->unmaped_payment($client_id);
    
            return view("client.bill_summary",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_info' => $client_info,'invoice_info' => $invoice_info,'invoice_recurring_info'=>$invoice_recurring_info,'connection_list'=>$connection_list,'task_list' => $task_list,'reference_by'=>$reference_by,'address_list'=>$address_list,'bill_summery'=>$bill_summery,'unmaped'=>$unmaped]);
        }else{
            redirect('client.list');
        }
	}
	
	public function list_summery_payment($client_id){
	    $array = DB::table('invoice')
					        ->where('client_id',$client_id)
					        ->Where('status', '!=',5)
					        ->where('status','!=',4)
                            ->get();
                            
        $array_final = array();
		$array_final_save = array();
		foreach($array as $array1)
		{
			
			$array_final['record_id'] = $array1->invoice_id;
			$array_final['invoice_id'] = $array1->invoice_id;
			$array_final['admin_id'] 	= $array1->admin_id;
			$array_final['record_type'] = "Invoice";
			$array_final['record_date'] = $array1->invoice_created_date;
			$array_final['status'] = $array1->status;
			$array2 = DB::table('invoice_details')->where('invoice_id',$array1->invoice_id)->get();
			
				if($array1->vat_status==1)
				{
					$vat = 0;
					$amount = 0;
					foreach($array2 as $array3)
					{
						$amount += ((float)$array3->price * (float)$array3->quantity);
						$vat += ((float)$array3->price * (float)$array3->quantity * (float)$array3->vat*.01);
					}
					$total_amount = $amount+$vat;
					$array_final['record_bill'] = $total_amount - $array1->discount;
				}else{
					$vat = 0;
					$amount = 0;
					foreach($array2 as $array3)
					{
						$amount += ((float)$array3->price * (float)$array3->quantity);
						$vat += ((float)$array3->price * (float)$array3->quantity * (float)$array3->vat*.01);
					}
					$total_amount = $amount;
					$array_final['record_bill'] = $total_amount - $array1->discount;
				}
			$array_final['accept_by'] = $array1->created_by;
			$invoice_data = array_push($array_final_save,$array_final);
		}
		
		$payment = DB::table('payment')->where('client_id',$client_id)->get();
		
		$payment_array = array();
		$payment_array_final = array();
		
		foreach($payment as $payments){
			$payment_array['record_id'] = $payments->id;
			$payment_array['invoice_id'] = $payments->invoice_id;
			$payment_array['admin_id'] 	= $payments->admin_id;
			$payment_array['record_type'] = "Payment";
			$payment_array['record_date'] = $payments->timestamp;
			$payment_array['record_bill'] = $payments->amount;
			$payment_array['accept_by'] = $payments->accept_by;
			$payment_array['cheque_po_number'] = $payments->cheque_po_number;
			$payment_array['status'] = $payments->status;
			array_push($array_final_save,$payment_array);
		}
		
		return $array_final_save;
	}
	
	public function unmaped_payment($client){
		$payment = DB::table('payment')->where('client_id',$client)->where('status','!=',1)->get();
		return $payment;
	}
	
	public function due_list()
	{
	    $title = 'Client Due List';
        $active_menu = 'client';
        $current_menu = 'client_due_list';
        $newdate = date("Y-m-d", strtotime("-30 days"));
  
		/*$client_list = DB::select("SELECT client.client_id,invoice.invoice_id,invoice.invoice_created_date,invoice.discount,invoice.vat_status,invoice.status FROM invoice INNER JOIN client on invoice.client_id = client.client_id WHERE DATE(invoice.invoice_created_date) < '$newdate' AND invoice.status ='1' GROUP BY invoice.client_id");
		echo '<pre>';
		print_r($client_list);
		exit();*/
		$client_list = DB::table('invoice')
		                    ->select(DB::raw('invoice.client_id,client.client_title,client.contact_person,client.client_phone1,client.client_phone2,client.is_vip_client,client.client_status,branch.branch_name'))
                            ->join('client', 'invoice.client_id','=','client.client_id')
                            ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                            ->where('invoice.status',1)
                            ->whereDate('invoice.invoice_created_date', '<', $newdate)
                            ->groupBy('invoice.client_id')
                            ->groupBy('client.client_title')
                            ->groupBy('client.contact_person')
                            ->groupBy('client.client_phone1')
                            ->groupBy('client.client_phone2')
                            ->groupBy('client.is_vip_client')
                            ->groupBy('client.client_status')
                            ->groupBy('branch.branch_name')
                            ->paginate(25);
       
   	    return view("client.client_due_list",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_list' => $client_list]);
	}
	
	public function client_invoice($id=NULL)
	{
	    $title = 'Client Details';
        $active_menu = 'client';
        $current_menu = 'client_list';
        
        $client_id = base64_decode($id);
        if($client_id){
            
            $client_info = DB::table('client')
					        ->where('client_id',$client_id)
                            ->first();
            $invoice_info = DB::table('invoice')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            $invoice_recurring_info = DB::table('invoice_recurring')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            
            $connection_list = DB::table('connection_list')
                            ->join('connection_network_details', 'connection_network_details.connection_id','=','connection_list.connection_id')
                            ->select('connection_list.connection_id','connection_list.client_address_id','connection_list.client_id','connection_list.auto_disconnect','connection_list.device_id','connection_list.connection_address','connection_list.activation_date','connection_list.link_status','connection_network_details.ip_address')
                            ->where('connection_list.client_id',$client_id)
                            ->orderBy('connection_list.connection_id','DESC')
                            ->get();
            $task_list		= DB::table('task_list')->where('client_id',$client_id)->get();
    		$reference_by	= DB::table('client')->where(array('reference_by'=>2,'reference_id'=>$client_id))->get();
    		$address_list	= DB::table('client_address')->where('client_id',$client_id)->get();
            
            return view("client.client_invoice",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_info' => $client_info,'invoice_info' => $invoice_info,'invoice_recurring_info'=>$invoice_recurring_info,'connection_list'=>$connection_list,'task_list' => $task_list,'reference_by'=>$reference_by,'address_list'=>$address_list]);
        }else{
            redirect('client.list');
        }
	}
	
	public function client_due_invoice($id=NULL)
	{
	    $title = 'Client Details';
        $active_menu = 'client';
        $current_menu = 'client_list';
        
        $client_id = base64_decode($id);
        if($client_id){
            
            $client_info = DB::table('client')
					        ->where('client_id',$client_id)
                            ->first();
            $invoice_info = DB::table('invoice')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            $invoice_due_info = DB::table('invoice')
					        ->where('client_id',$client_id)
					        ->where('status',1)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            $invoice_recurring_info = DB::table('invoice_recurring')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            
            $connection_list = DB::table('connection_list')
                            ->join('connection_network_details', 'connection_network_details.connection_id','=','connection_list.connection_id')
                            ->select('connection_list.connection_id','connection_list.client_address_id','connection_list.client_id','connection_list.auto_disconnect','connection_list.device_id','connection_list.connection_address','connection_list.activation_date','connection_list.link_status','connection_network_details.ip_address')
                            ->where('connection_list.client_id',$client_id)
                            ->orderBy('connection_list.connection_id','DESC')
                            ->get();
            $task_list		= DB::table('task_list')->where('client_id',$client_id)->get();
    		$reference_by	= DB::table('client')->where(array('reference_by'=>2,'reference_id'=>$client_id))->get();
    		$address_list	= DB::table('client_address')->where('client_id',$client_id)->get();
            
            return view("client.client_due_invoice",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_info' => $client_info,'invoice_info' => $invoice_info,'invoice_due_info'=>$invoice_due_info,'invoice_recurring_info'=>$invoice_recurring_info,'connection_list'=>$connection_list,'task_list' => $task_list,'reference_by'=>$reference_by,'address_list'=>$address_list]);
        }else{
            redirect('client.list');
        }
	}
	
	public function client_bad_debt_invoice($id=NULL)
	{
	    $title = 'Client Details';
        $active_menu = 'client';
        $current_menu = 'client_list';
        
        $client_id = base64_decode($id);
        if($client_id){
            
            $client_info = DB::table('client')
					        ->where('client_id',$client_id)
                            ->first();
            $invoice_info = DB::table('invoice')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            $invoice_bd_info = DB::table('invoice')
					        ->where('client_id',$client_id)
					        ->where('status',6)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            $invoice_recurring_info = DB::table('invoice_recurring')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            
            $connection_list = DB::table('connection_list')
                            ->join('connection_network_details', 'connection_network_details.connection_id','=','connection_list.connection_id')
                            ->select('connection_list.connection_id','connection_list.client_address_id','connection_list.client_id','connection_list.auto_disconnect','connection_list.device_id','connection_list.connection_address','connection_list.activation_date','connection_list.link_status','connection_network_details.ip_address')
                            ->where('connection_list.client_id',$client_id)
                            ->orderBy('connection_list.connection_id','DESC')
                            ->get();
            $task_list		= DB::table('task_list')->where('client_id',$client_id)->get();
    		$reference_by	= DB::table('client')->where(array('reference_by'=>2,'reference_id'=>$client_id))->get();
    		$address_list	= DB::table('client_address')->where('client_id',$client_id)->get();
            
            return view("client.client_bad_debt_invoice",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_info' => $client_info,'invoice_info' => $invoice_info,'invoice_bd_info'=>$invoice_bd_info,'invoice_recurring_info'=>$invoice_recurring_info,'connection_list'=>$connection_list,'task_list' => $task_list,'reference_by'=>$reference_by,'address_list'=>$address_list]);
        }else{
            redirect('client.list');
        }
	}
	
	public function client_recurring($id=NULL)
	{
	    $title = 'Client Details';
        $active_menu = 'client';
        $current_menu = 'client_list';
        
        $client_id = base64_decode($id);
        if($client_id){
            
            $client_info = DB::table('client')
					        ->where('client_id',$client_id)
                            ->first();
            $invoice_info = DB::table('invoice')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            $invoice_recurring_info = DB::table('invoice_recurring')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            
            $connection_list = DB::table('connection_list')
                            ->join('connection_network_details', 'connection_network_details.connection_id','=','connection_list.connection_id')
                            ->select('connection_list.connection_id','connection_list.client_address_id','connection_list.client_id','connection_list.auto_disconnect','connection_list.device_id','connection_list.connection_address','connection_list.activation_date','connection_list.link_status','connection_network_details.ip_address')
                            ->where('connection_list.client_id',$client_id)
                            ->orderBy('connection_list.connection_id','DESC')
                            ->get();
            $task_list		= DB::table('task_list')->where('client_id',$client_id)->get();
    		$reference_by	= DB::table('client')->where(array('reference_by'=>2,'reference_id'=>$client_id))->get();
    		$address_list	= DB::table('client_address')->where('client_id',$client_id)->get();
            
            return view("client.client_recurring",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_info' => $client_info,'invoice_info' => $invoice_info,'invoice_recurring_info'=>$invoice_recurring_info,'connection_list'=>$connection_list,'task_list' => $task_list,'reference_by'=>$reference_by,'address_list'=>$address_list]);
        }else{
            redirect('client.list');
        }
	}
	
	public function client_connection($id=NULL)
	{
	    $title = 'Client Details';
        $active_menu = 'client';
        $current_menu = 'client_list';
        
        $client_id = base64_decode($id);
        if($client_id){
            
            $client_info = DB::table('client')
					        ->where('client_id',$client_id)
                            ->first();
            $invoice_info = DB::table('invoice')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            $invoice_recurring_info = DB::table('invoice_recurring')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            
            $connection_list = DB::table('connection_list')
                            ->join('connection_network_details', 'connection_network_details.connection_id','=','connection_list.connection_id')
                            ->select('connection_list.connection_id','connection_list.client_address_id','connection_list.client_id','connection_list.auto_disconnect','connection_list.device_id','connection_list.connection_address','connection_list.activation_date','connection_list.link_status','connection_network_details.ip_address')
                            ->where('connection_list.client_id',$client_id)
                            ->orderBy('connection_list.connection_id','DESC')
                            ->get();
            $task_list		= DB::table('task_list')->where('client_id',$client_id)->get();
    		$reference_by	= DB::table('client')->where(array('reference_by'=>2,'reference_id'=>$client_id))->get();
    		$address_list	= DB::table('client_address')->where('client_id',$client_id)->get();
            
            return view("client.client_connection",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_info' => $client_info,'invoice_info' => $invoice_info,'invoice_recurring_info'=>$invoice_recurring_info,'connection_list'=>$connection_list,'task_list' => $task_list,'reference_by'=>$reference_by,'address_list'=>$address_list]);
        }else{
            redirect('client.list');
        }
	}
	
	public function client_task($id=NULL)
	{
	    $title = 'Client Details';
        $active_menu = 'client';
        $current_menu = 'client_list';
        
        $client_id = base64_decode($id);
        if($client_id){
            
            $client_info = DB::table('client')
					        ->where('client_id',$client_id)
                            ->first();
            $invoice_info = DB::table('invoice')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            $invoice_recurring_info = DB::table('invoice_recurring')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            
            $connection_list = DB::table('connection_list')
                            ->join('connection_network_details', 'connection_network_details.connection_id','=','connection_list.connection_id')
                            ->select('connection_list.connection_id','connection_list.client_address_id','connection_list.client_id','connection_list.auto_disconnect','connection_list.device_id','connection_list.connection_address','connection_list.activation_date','connection_list.link_status','connection_network_details.ip_address')
                            ->where('connection_list.client_id',$client_id)
                            ->orderBy('connection_list.connection_id','DESC')
                            ->get();
            $task_list		= DB::table('task_list')->where('client_id',$client_id)->get();
    		$reference_by	= DB::table('client')->where(array('reference_by'=>2,'reference_id'=>$client_id))->get();
    		$address_list	= DB::table('client_address')->where('client_id',$client_id)->get();
            
            return view("client.client_task",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_info' => $client_info,'invoice_info' => $invoice_info,'invoice_recurring_info'=>$invoice_recurring_info,'connection_list'=>$connection_list,'task_list' => $task_list,'reference_by'=>$reference_by,'address_list'=>$address_list]);
        }else{
            redirect('client.list');
        }
	}
	
	public function client_referral($id=NULL)
	{
	    $title = 'Client Details';
        $active_menu = 'client';
        $current_menu = 'client_list';
        
        $client_id = base64_decode($id);
        if($client_id){
            
            $client_info = DB::table('client')
					        ->where('client_id',$client_id)
                            ->first();
            $invoice_info = DB::table('invoice')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            $invoice_recurring_info = DB::table('invoice_recurring')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            
            $connection_list = DB::table('connection_list')
                            ->join('connection_network_details', 'connection_network_details.connection_id','=','connection_list.connection_id')
                            ->select('connection_list.connection_id','connection_list.client_address_id','connection_list.client_id','connection_list.auto_disconnect','connection_list.device_id','connection_list.connection_address','connection_list.activation_date','connection_list.link_status','connection_network_details.ip_address')
                            ->where('connection_list.client_id',$client_id)
                            ->orderBy('connection_list.connection_id','DESC')
                            ->get();
            $task_list		= DB::table('task_list')->where('client_id',$client_id)->get();
    		$reference_by	= DB::table('client')->where(array('reference_by'=>2,'reference_id'=>$client_id))->get();
    		$address_list	= DB::table('client_address')->where('client_id',$client_id)->get();
            
            return view("client.client_referral",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_info' => $client_info,'invoice_info' => $invoice_info,'invoice_recurring_info'=>$invoice_recurring_info,'connection_list'=>$connection_list,'task_list' => $task_list,'reference_by'=>$reference_by,'address_list'=>$address_list]);
        }else{
            redirect('client.list');
        }
	}
	
	public function client_address($id=NULL)
	{
	    $title = 'Client Details';
        $active_menu = 'client';
        $current_menu = 'client_list';
        
        $client_id = base64_decode($id);
        if($client_id){
            
            $client_info = DB::table('client')
					        ->where('client_id',$client_id)
                            ->first();
            $invoice_info = DB::table('invoice')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            $invoice_recurring_info = DB::table('invoice_recurring')
					        ->where('client_id',$client_id)
					        ->orderBy('invoice_created_date','DESC')
                            ->get();
            
            $connection_list = DB::table('connection_list')
                            ->join('connection_network_details', 'connection_network_details.connection_id','=','connection_list.connection_id')
                            ->select('connection_list.connection_id','connection_list.client_address_id','connection_list.client_id','connection_list.auto_disconnect','connection_list.device_id','connection_list.connection_address','connection_list.activation_date','connection_list.link_status','connection_network_details.ip_address')
                            ->where('connection_list.client_id',$client_id)
                            ->orderBy('connection_list.connection_id','DESC')
                            ->get();
            $task_list		= DB::table('task_list')->where('client_id',$client_id)->get();
    		$reference_by	= DB::table('client')->where(array('reference_by'=>2,'reference_id'=>$client_id))->get();
    		$address_list	= DB::table('client_address')->where('client_id',$client_id)->get();
            
            return view("client.client_address",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_info' => $client_info,'invoice_info' => $invoice_info,'invoice_recurring_info'=>$invoice_recurring_info,'connection_list'=>$connection_list,'task_list' => $task_list,'reference_by'=>$reference_by,'address_list'=>$address_list]);
        }else{
            redirect('client.list');
        }
	}
	
	public function print_paper($id = NULL)
    {
        $client_id = base64_decode($id);
        $client_info = DB::table('client')
					        ->where('client_id',$client_id)
                            ->first();
        $packages = DB::select("SELECT invoice_recurring.client_id,invoice_recurring.client_address_id,invoice_recurring.status,invoice_recurring_details.*
									FROM invoice_recurring INNER JOIN invoice_recurring_details ON
									invoice_recurring.invoice_id = invoice_recurring_details.invoice_id
									WHERE invoice_recurring.client_id = '$client_id'");
	
        $pdf = PDF::loadView('client.print_paper',array('details' =>$client_info,'packages' =>$packages));
        return $pdf->download('paper_'.$client_id.'.pdf');
    }
	
	function fetch(Request $request)
    {
     if($request->get('query'))
     {
      $query = $request->get('query');
      $data = DB::table('client')
                        ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                        ->select('client.client_id', 'client.client_title','client.contact_person','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name')
                        ->where('client.client_title', 'LIKE', "%{$query}%")
                        ->get();
      $output = '<ul class="dropdown-menu" style="display:block; position:relative">';
      foreach($data as $row)
      {
       $output .= '
       <li><a href="#">'.$row->client_title.'</a></li>
       ';
      }
      $output .= '</ul>';
      echo $output;
     }
    }
    
    public function autocomplete_list(Request $request){

        $title = 'Client List';
        $active_menu = 'client';
        $current_menu = 'client_all';
   	    return view("client.autocomplete",['title' => $title,'active_menu' => $active_menu, 'current_menu' => $current_menu]);

	}
	
	public function ajaxData(Request $request){

        $query = $request->get('query','');
        
        $clients = DB::table('client')
                            ->select('client_title as name')
                            ->Where('client_title', 'LIKE', '%' . $query . '%')
                            ->get();
                            
        return response()->json($clients);

	}
	
	public function autocomplete(Request $request){
	    $q = $request->name;
	    $data = DB::table('client')
                        ->join('branch', 'client.branch_id', '=', 'branch.branch_id')
                        ->select('client.client_id', 'client.client_title as name','client.contact_person','client.client_email1', 'client.client_email2', 'client.client_phone1', 'client.client_phone2', 'client.client_status','branch.branch_name')
                        ->where('client.client_id', 'LIKE', "%{$q}%")
                        ->orWhere('client.client_title', 'LIKE', "%{$q}%")
                        ->orWhere('client.contact_person', 'LIKE', "%{$q}%")
                        ->orWhere('client.client_email1', 'LIKE', "%{$q}%")
                        ->orWhere('client.client_email2', 'LIKE', "%{$q}%")
                        ->orWhere('client.client_phone1', 'LIKE', "%{$q}%")
                        ->orWhere('client.client_phone2', 'LIKE', "%{$q}%")
                        ->orWhere('client.client_username', 'LIKE', "%{$q}%")
                        ->get();
		return response()->json($data);
    }
	
	public function total_invoice_popup($id=NULL)
	{
		$client_id = $id;
		$client_data =DB::table('client')->where('client_id',$client_id)->first();
		if($client_data){
		    $client_title =  $client_data->client_title.' (IL-C'.$client_id.')';
		}else{
		    $client_title =  "";
		}
		$invoice_info = DB::table('invoice')
		             ->select('client_id','invoice_id','invoice_created_date','bill_period','vat_status','status','discount')
                     ->where('client_id', '=', $client_id)
                     ->where('status', '!=', 5)
                     ->orderBy('invoice_created_date','DESC')
                     ->get();
		/*$this->db->select("client_id,invoice_id,invoice_created_date,bill_period,vat_status,status,discount");
		$this->db->from("invoice");
		$this->db->where('client_id',$client_id);
		$this->db->order_by('invoice_created_date','DESC');
		$invoice_info = $this->db->get()->result(); */
		
										
		$cdata1 = '';
		if($invoice_info){
				$cdata1 .= '<div class="modal-header">
										<h4 class="modal-title">'.count($invoice_info).' Invoice of '.$client_title.'</h4>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										  <span aria-hidden="true">&times;</span>
										</button>
									  </div>
								<div class="modal-body">
							    <div class="table-responsive">
								<table class="table table-hover">
									<thead>
										<tr>
										  <th>SL</th>
										  <th>Inv. No</th>
										  <th>Date</th>
										  <th>Amount</th>
										  <th>T Amount</th>
										  <th>Action</th>
										</tr>
									</thead>
									<tbody>';
					$i = 0;
						foreach($invoice_info as $lists)
						{
							$i++;
							$cdata1 .= '<tr>';
							$cdata1 .= '<th>'.$i.'</th>';
							$cdata1 .= '<th>IL-'.$lists->invoice_id.'<br/>';
							
								if($lists->status==1)
								{
									$cdata1 .= "<span style='color:red;'>Due</span>";
								}elseif($lists->status==3){
									$cdata1 .= "<span style='color:green;'>Paid</span>";
								}elseif($lists->status==2){
									$cdata1 .="<span style='color:blue;'>Partialy Paid</span>";
								}elseif($lists->status==4){
									$cdata1 .= "Cancel";
								}elseif($lists->status==5){
									$cdata1 .= "Deleted";
								}elseif($lists->status==6){
									$cdata1 .= "Bad Debt";
								}else{
									$cdata1 .= "<span style='color:blue;'>Pending</span>";
								}
							$cdata1 .= '</th>';
							$cdata1 .= '<td>'.date('d-m-Y',strtotime($lists->invoice_created_date)).'<br/>'.$lists->bill_period.'</td>';
							
							//$result_invoice = $this->db->select('price,quantity,vat')->where('invoice_id',$lists->invoice_id)->get('invoice_details')->result();
							$result_invoice = DB::table('invoice_details')
                    		             ->select('price','quantity','vat')
                                         ->where('invoice_id', '=', $lists->invoice_id)
                                         ->get();
							$amount = 0;
							$vat = 0;
							$v = 0;
							foreach($result_invoice as $invoice_info)
							{
								$amount += ((float)$invoice_info->price*(float)$invoice_info->quantity);
								$vat += ((float)$invoice_info->quantity*(float)$invoice_info->price*(float)$invoice_info->vat*.01);
							}
							$total_vat = $vat;
							$total_amount = $amount-$lists->discount;
							if($vat){
							    $v = (($vat * 100)/$amount);
							}else{
							    $v = 0;
							}
							
							
							$cdata1 .= '<th>'.number_format($amount,2).'<br>';
							$cdata1 .= number_format($vat,2).'('.number_format($v).'%)';
							$cdata1 .= '</th>';
							if($lists->vat_status==1)
							{
								$cdata1 .= '<th>'.number_format($total_vat+$total_amount,2);
								if($lists->discount){ 
								    $cdata1 .= '<br/>D:'.$lists->discount;
								}
								$cdata1.= '</th>';
							}else{
								$cdata1 .= '<th>'.number_format($total_amount,2);
								if($lists->discount){ 
								    $cdata1 .= '<br/>D:'.$lists->discount;
								}
								$cdata1.= '</th>';
							}
							$cdata1.= '<th>';
							if($lists->status == 3 OR $lists->status==0){
							    $cdata1 .= '';
							}else{
							    $cdata1 .= '<a href="'.URL('invoice/add_payment/'.base64_encode($lists->invoice_id)).'" class="btn btn-primary btn-xs"><i class="fa fa-plus"></i> Payment</a><br/>';						
							}
							$cdata1 .= '<a href="'.URL('invoice/details/'.base64_encode($lists->invoice_id)).'" class="btn btn-primary btn-xs"><i class="fa fa-check"></i> Details</a>&nbsp';
							$cdata1 .= '<a href="'.URL('invoice/download/'.base64_encode($lists->invoice_id)).'" class="btn btn-primary btn-xs"><i class="fa fa-print"></i> Print</a>';
							
							$cdata1 .= "</th>";
							$cdata1 .= '</tr>';

						}
						$cdata1 .= '</table></div></div>
                        						<div class="modal-footer justify-content-between">
                                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                      <button type="button" class="btn btn-primary">Save changes</button>
                                    </div>';
						echo $cdata1;
				}else{
					echo '<div class="modal-header">
                              <h4 class="modal-title">Large Modal</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body">
                              <p>No Invoice Found</p>
                            </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              <button type="button" class="btn btn-primary">Save changes</button>
                            </div>';
				}
		
	}
	
	public function total_due_invoice_popup($id=NULL)
	{
		$client_id = $id;
		$client_data =DB::table('client')->where('client_id',$client_id)->first();
		if($client_data){
		    $client_title =  $client_data->client_title.' (IL-C'.$client_id.')';
		}else{
		    $client_title =  "";
		}
		$invoice_info = DB::table('invoice')
		             ->select('client_id','invoice_id','invoice_created_date','bill_period','vat_status','status','discount')
                     ->where('client_id', '=', $client_id)
                     ->where('status', '=', 1)
                     ->orderBy('invoice_created_date','DESC')
                     ->get();
		/*$this->db->select("client_id,invoice_id,invoice_created_date,bill_period,vat_status,status,discount");
		$this->db->from("invoice");
		$this->db->where('client_id',$client_id);
		$this->db->order_by('invoice_created_date','DESC');
		$invoice_info = $this->db->get()->result(); */
		
										
		$cdata1 = '';
		if($invoice_info){
				$cdata1 .= '<div class="modal-header">
										<h4 class="modal-title">'.count($invoice_info).' Due Invoice of '.$client_title.'</h4>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										  <span aria-hidden="true">&times;</span>
										</button>
									  </div>
								<div class="modal-body">
							    <div class="table-responsive">
								<table class="table table-hover">
									<thead>
										<tr>
										  <th>SL</th>
										  <th>Inv. No</th>
										  <th>Date</th>
										  <th>Amount</th>
										  <th>T Amount</th>
										  <th>Action</th>
										</tr>
									</thead>
									<tbody>';
					$i = 0;
						foreach($invoice_info as $lists)
						{
							$i++;
							$cdata1 .= '<tr>';
							$cdata1 .= '<th>'.$i.'</th>';
							$cdata1 .= '<th>IL-'.$lists->invoice_id.'<br/>';
							
								if($lists->status==1)
								{
									$cdata1 .= "<span style='color:red;'>Due</span>";
								}elseif($lists->status==3){
									$cdata1 .= "<span style='color:green;'>Paid</span>";
								}elseif($lists->status==2){
									$cdata1 .="<span style='color:blue;'>Partialy Paid</span>";
								}elseif($lists->status==4){
									$cdata1 .= "Cancel";
								}elseif($lists->status==5){
									$cdata1 .= "Deleted";
								}elseif($lists->status==6){
									$cdata1 .= "Bad Debt";
								}else{
									$cdata1 .= "<span style='color:blue;'>Pending</span>";
								}
							$cdata1 .= '</th>';
							$cdata1 .= '<td>'.date('d-m-Y',strtotime($lists->invoice_created_date)).'<br/>'.$lists->bill_period.'</td>';
							
							//$result_invoice = $this->db->select('price,quantity,vat')->where('invoice_id',$lists->invoice_id)->get('invoice_details')->result();
							$result_invoice = DB::table('invoice_details')
                    		             ->select('price','quantity','vat')
                                         ->where('invoice_id', '=', $lists->invoice_id)
                                         ->get();
							$amount = 0;
							$vat = 0;
							$v = 0;
							foreach($result_invoice as $invoice_info)
							{
								$amount += ((float)$invoice_info->price*(float)$invoice_info->quantity);
								$vat += ((float)$invoice_info->quantity*(float)$invoice_info->price*(float)$invoice_info->vat*.01);
							}
							$total_vat = $vat;
							$total_amount = $amount-$lists->discount;
							if($vat){
							    $v = (($vat * 100)/$amount);
							}else{
							    $v = 0;
							}
							
							
							$cdata1 .= '<th>'.number_format($amount,2).'<br>';
							$cdata1 .= number_format($vat,2).'('.number_format($v).'%)';
							$cdata1 .= '</th>';
							if($lists->vat_status==1)
							{
								$cdata1 .= '<th>'.number_format($total_vat+$total_amount,2);
								if($lists->discount){ 
								    $cdata1 .= '<br/>D:'.$lists->discount;
								}
								$cdata1.= '</th>';
							}else{
								$cdata1 .= '<th>'.number_format($total_amount,2);
								if($lists->discount){ 
								    $cdata1 .= '<br/>D:'.$lists->discount;
								}
								$cdata1.= '</th>';
							}
							$cdata1.= '<th>';
							if($lists->status == 3 OR $lists->status==0){
							    $cdata1 .= '';
							}else{
								$cdata1 .="<a href='' target='_blank' class='btn btn-xs btn-danger'><i class='fa fa-plus'></i> Payment</a><br/>";							
							}
							$cdata1 .= "<a href='' target='_blank' class='btn btn-xs btn-primary'>Details</a>&nbsp;";
							$cdata1 .= "<a href='' target='_blank' class='btn btn-xs btn-info'>Print</a>";
							
							$cdata1 .= "</th>";
							$cdata1 .= '</tr>';

						}
						$cdata1 .= '</table></div></div>
                        						<div class="modal-footer justify-content-between">
                                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                      <button type="button" class="btn btn-primary">Save changes</button>
                                    </div>';
						echo $cdata1;
				}else{
					echo '<div class="modal-header">
                              <h4 class="modal-title">Large Modal</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body">
                              <p>No Invoice Found</p>
                            </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              <button type="button" class="btn btn-primary">Save changes</button>
                            </div>';
				}
		
	}
	
	public function total_recurring_invoice_popup($id=NULL)
	{
		$client_id = $id;
		$client_data =DB::table('client')->where('client_id',$client_id)->first();
		if($client_data){
		    $client_title =  $client_data->client_title.' (IL-C'.$client_id.')';
		}else{
		    $client_title =  "";
		}
		$invoice_info = DB::table('invoice_recurring')
		             ->select('client_id','invoice_id','invoice_created_date','bill_period','vat_status','status','discount')
                     ->where('client_id', '=', $client_id)
                     ->where('status', '!=', 2)
                     ->orderBy('invoice_created_date','DESC')
                     ->get();
		/*$this->db->select("client_id,invoice_id,invoice_created_date,bill_period,vat_status,status,discount");
		$this->db->from("invoice");
		$this->db->where('client_id',$client_id);
		$this->db->order_by('invoice_created_date','DESC');
		$invoice_info = $this->db->get()->result(); */
		
										
		$cdata1 = '';
		if($invoice_info){
				$cdata1 .= '<div class="modal-header">
										<h4 class="modal-title">'.count($invoice_info).' Recurring Invoice of '.$client_title.'</h4>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										  <span aria-hidden="true">&times;</span>
										</button>
									  </div>
								<div class="modal-body">
							    <div class="table-responsive">
								<table class="table table-hover">
									<thead>
										<tr>
										  <th>SL</th>
										  <th>Inv. No</th>
										  <th>Date</th>
										  <th>Amount</th>
										  <th>T Amount</th>
										  <th>Action</th>
										</tr>
									</thead>
									<tbody>';
					$i = 0;
						foreach($invoice_info as $lists)
						{
							$i++;
							$cdata1 .= '<tr>';
							$cdata1 .= '<th>'.$i.'</th>';
							$cdata1 .= '<th>IL-'.$lists->invoice_id.'<br/>';
							
								if($lists->status==1)
								{
									$cdata1 .= "<span style='color:green;'>Active</span>";
								}else{
									$cdata1 .= "<span style='color:red;'>Inactive</span>";
								}
							$cdata1 .= '</th>';
							$cdata1 .= '<td>'.date('d-m-Y',strtotime($lists->invoice_created_date)).'<br/>'.$lists->bill_period.'</td>';
							
							//$result_invoice = $this->db->select('price,quantity,vat')->where('invoice_id',$lists->invoice_id)->get('invoice_details')->result();
							$result_invoice = DB::table('invoice_recurring_details')
                    		             ->select('price','quantity','vat')
                                         ->where('invoice_id', '=', $lists->invoice_id)
                                         ->get();
							$amount = 0;
							$vat = 0;
							$v = 0;
							foreach($result_invoice as $invoice_info)
							{
								$amount += ((float)$invoice_info->price*(float)$invoice_info->quantity);
								$vat += ((float)$invoice_info->quantity*(float)$invoice_info->price*(float)$invoice_info->vat*.01);
							}
							$total_vat = $vat;
							$total_amount = $amount-$lists->discount;
							if($vat){
							    $v = (($vat * 100)/$amount);
							}else{
							    $v = 0;
							}
							
							
							$cdata1 .= '<th>'.number_format($amount,2).'<br>';
							$cdata1 .= number_format($vat,2).'('.number_format($v).'%)';
							$cdata1 .= '</th>';
							if($lists->vat_status==1)
							{
								$cdata1 .= '<th>'.number_format($total_vat+$total_amount,2);
								if($lists->discount){ 
								    $cdata1 .= '<br/>D:'.$lists->discount;
								}
								$cdata1.= '</th>';
							}else{
								$cdata1 .= '<th>'.number_format($total_amount,2);
								if($lists->discount){ 
								    $cdata1 .= '<br/>D:'.$lists->discount;
								}
								$cdata1.= '</th>';
							}
							$cdata1.= '<th>';
							$cdata1 .= "<a href='' target='_blank' class='btn btn-xs btn-primary'>Details</a>&nbsp;";
							
							$cdata1 .= "</th>";
							$cdata1 .= '</tr>';

						}
						$cdata1 .= '</table></div></div>
                        						<div class="modal-footer justify-content-between">
                                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                      <button type="button" class="btn btn-primary">Save changes</button>
                                    </div>';
						echo $cdata1;
				}else{
					echo '<div class="modal-header">
                              <h4 class="modal-title">Large Modal</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body">
                              <p>No Invoice Found</p>
                            </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              <button type="button" class="btn btn-primary">Save changes</button>
                            </div>';
				}
		
	}
	
	function total_connection_popup($id=NULL){
		$c_id = $id;
		$client_data =DB::table('client')->where('client_id',$c_id)->first();
		if($client_data){
		    $client_title =  $client_data->client_title.' (IL-C'.$c_id.')';
		}else{
		    $client_title =  "";
		}
		$connection_list = DB::table('connection_list')
                     ->where('client_id', '=', $c_id)
                     ->get();
		$cdata1 = '';
		 	if($connection_list){
			
			$cdata1 .= '<div class="modal-header">
										<h5 class="modal-title" id="exampleModalLabel">'.count($connection_list).' Connection of '.$client_title.'</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										  <span aria-hidden="true">&times;</span>
										</button>
									  </div>
								<div class="modal-body">
								<div class="table-responsive"><table class="table table-hover">
				 <tr>
					<th>SL</th>
					<th>Conn ID</th>
					<th>Conn Address</th>
					<th>Contact Person</th>
					<th>IP</th>
					<th>Automation</th>
					<th>Date</th>
					<th>Action</th>
				 </tr>';
				$i = 0;
					foreach($connection_list as $lists)
					{
						$i++;
						$cdata1 .= '<tr>';
						$cdata1 .= '<td>'.$i.'</td>';
						$cdata1 .= '<th> CID'.$lists->connection_id.'<br/>';
						if($lists->link_status == 1){
								$cdata1 .= "<span style='color: green;'>Active</span>";
							}elseif($lists->link_status == 2){
								$cdata1 .= "<span style='color: red;'>Inactive</span>";
							}elseif($lists->link_status == 3){
								$cdata1 .= "<span style='color: red;'>Pending</span>";
							}elseif($lists->link_status == 4){
								$cdata1 .= 'Cancel';
							}
						
						$cdata1 .= '</th>';
						$cdata1 .= '<td>'.$lists->connection_address.'</td>';
					    $cdata1 .= '<td>'.$lists->contact_person_name.'<br/>'.$lists->contact_number.'</td>';
					    $cdata1 .= '<td>';
					    $ip_address = DB::table('connection_network_details')->where('connection_id',$lists->connection_id)->first();
    					    if($ip_address){
    					    $ip = explode(',',$ip_address->ip_address);
        						foreach($ip as $val){
        							$cdata1 .= $val.'<br/>';
        						}
					        }else{
					            $cdata1 .= '';
					        }
						$cdata1 .= '</td>';
						$cdata1 .= '<td>';
						if($lists->auto_disconnect == 1){
							$cdata1 .= "<b style='color:green;'>";
							$ip_result = DB::table('connection_ip')->where('connection_id',$lists->connection_id)->get();
							if($ip_result){
								foreach($ip_result as $value){
									$cdata1 .= $value->ip_address.'<br/>';
								}
							}else{
							    $cdata1 .= '';
							}
							$cdata1 .= "</b>";
						}else{
							$cdata1 .= "<b style='color:red;'>Off</b>";
						}
						$cdata1 .= '</td>';
					    $cdata1 .= '<td>'.$lists->activation_date.'</td>';
						
						$cdata1 .= "<th><a href='' target='_blank' class='btn btn-xs btn-primary'>Details</a>";
						$cdata1 .= '</tr>';

					}
					$cdata1 .= '</table></div></div>
						<div class="modal-footer">
											<button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
										</div>';
					echo $cdata1;
			}else{
				echo '<div class="modal-header">
										<h5 class="modal-title" id="exampleModalLabel">'.count($connection_list).' Connection of '.$client_title.'</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										  <span aria-hidden="true">&times;</span>
										</button>
									  </div>
								<div class="modal-body">
								No Connection found
								</div>
							</div><div class="modal-footer">
											<button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
										</div>';
			}
			
    }
    
    
    public function add_package($id=NULL)
	{
	    $title = 'Add Package';
        $active_menu = 'client';
        $current_menu = 'client_list';
        
        $client_id = base64_decode($id);
        if($client_id){
								   
            $client_info = DB::table('client')
					        ->where('client_id',$client_id)
                            ->first();
            $home_internet=DB::table('package')
                            ->where('group_id',1)
                            ->get();
            $corporate=DB::table('package')
                            ->where('group_id',2)
                            ->get();
            
            $SME=DB::table('package')
                            ->where('group_id',5)
                            ->get();
            
            $server=DB::table('package')
                            ->where('group_id',6)
                            ->get();
                            
            $hosting=DB::table('package')
                            ->where('group_id',7)
                            ->get();
                            
            $tracker=DB::table('package')
                            ->where('group_id',8)
                            ->get();
            
            return view("client.client_add_package",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_info' => $client_info,'home_internet' => $home_internet,'corporate'=>$corporate,'SME'=>$SME,'server' => $server,'hosting'=>$hosting,'tracker'=>$tracker]);                
        }else{
            redirect('client.list');
        }
	}
    
    public function package_details($pid=NULL,$c_id=NULL)
	{
	    $title = 'Package Details';
        $active_menu = 'client';
        $current_menu = 'client_list';
        $client_id = base64_decode($c_id);
        $package_id = base64_decode($pid);
        
        $client_info = DB::table('client')
				        ->where('client_id',$client_id)
                        ->first();
                        
        $package_info = DB::table('package')
				        ->where('package_id',$package_id)
                        ->first();
      
        return view("client.package_details",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_info' => $client_info,'pack_details' => $package_info]);
	}
	
	public function package_order(Request $request,$package_id=NULL,$client_id=NULL){
	    if ($request->address_id) {
			$address_id = $request->address_id;
		}else{
			$address_id = '';
		}

		if ($request->coverage_area) {
			$coverage_area = $request->coverage_area;
		}else{
			$coverage_area = '';
		}
		if ($request->company_name) {
			$company_name = $request->company_name;
		}else{
			$company_name = '';
		}
		if ($request->vat_number) {
			$vat_number = $request->vat_number;
		}else{
			$vat_number = '';
		}
	
		if ($request->package_id) {
			$package_id = $request->package_id;
		} else {
			$package_id = '';
		}
	
		$otc = trim($request->otc);
		$mrc = trim($request->mrc);
		$vat_amount = trim($request->vat_amount);
		$vat = trim($request->vat);
		
		$todayDay = date('j');
		$todayMonth = date('n');
		$todayYear = date('Y');
		$totalDaysOfTheMonth =  cal_days_in_month(CAL_GREGORIAN, $todayMonth, $todayYear);
		$bill_period = '';
		
		$mrc_price = 0;
		if($todayDay >= 1 AND $todayDay <= 10){
			$mrc_price = $mrc;
		}elseif($todayDay >= 11 AND $todayDay <= 20){
			$mrc_price = ($mrc / 2);
		}elseif($todayDay >= 21 AND $todayDay <= $totalDaysOfTheMonth){
			$mrc_price = $mrc;
		}else{
			$mrc_price = 0;
		}
	    
	    $data = array();
        $data['client_id'] = $client_id;
        $data['billing_address_id'] = $address_id;
        $data['status'] = 1;
      
        $insert_id = DB::table('order_cart')->insertGetId($data);
	  
		if($insert_id){
			$data1['order_cart_id'] = $insert_id;
			$data1['client_id'] = $client_id;
			$data1['package_id'] = $package_id; 
			$data1['otc_price'] = $otc; 
			$data1['mrc_price'] = $mrc_price; 
			$data1['vat'] = $vat;
			$data1['vat_price'] = $vat_amount; 
			$data1['connection_address_id'] = $address_id;
			$data1['coverage_area'] = $coverage_area;
			$data1['company_name'] = $company_name;  
			$data1['vat_reg_number'] = $vat_number;
		    DB::table('order_cart_details')->insert($data1);
		}
        $request->session()->flash('status','Card Added Successfully');
        return redirect('client/add_package/'.base64_encode($client_id));
        
    }
    
    public function package_checkout($c_id = NULL){
		$client_id = base64_decode($c_id);
		$client_info = DB::table('client')->where('client_id',$client_id)->first();
		$title = "Review & Checkout [".$client_info->client_title.' (ILC-'.$client_id.')]';
        $active_menu = 'client';
        $current_menu = 'client_list';
        
		$order_cart = DB::table('order_cart')->where('client_id',$client_id)->first();
		
		$order_cart_data = DB::select("SELECT order_cart.*,
                                		package.package_name,package.package_type,package.connectivity_type,package.download_speed,package.d_unit,package.upload_speed,package.u_unit,package.setup_price,package.ref_discount,package.package_price_1,package.package_vat as p_vat,package.income_category_id,
                                		package_group.group_name,
                                        order_cart_details.*
										FROM order_cart INNER JOIN order_cart_details ON order_cart.order_cart_id = order_cart_details.order_cart_id
										INNER JOIN package ON order_cart_details.package_id = package.package_id
										INNER JOIN package_group ON package.group_id = package_group.package_group_id WHERE order_cart.client_id = '$client_id'");
		
	    return view("client.package_checkout",['title' => $title,'privillige_menu'=> $this->privillige_menu,'active_menu' => $active_menu, 'current_menu' => $current_menu,'client_info' => $client_info,'order_cart' => $order_cart,'order_cart_data'=>$order_cart_data]);												
    }
    
    public function deletecart($o_cart_details_id=NULL,$c_id = NULL){
		$order_cart_details_id = base64_decode($o_cart_details_id);
		$client_id = base64_decode($c_id);
		$del = DB::table('order_cart_details')->where('order_cart_details_id',$order_cart_details_id)->delete();
		if ($del) {
			$check_order = DB::table('order_cart_details')->where('client_id',$client_id)->first();
			if($check_order){
			    Session::flash('status','Cart Item Deleted Successfully');
			    return redirect('client/checkout/'.base64_encode($client_id));
			}else{
				$order_cart_delete = DB::table('order_cart')->where('client_id',$client_id)->delete();
				if($order_cart_delete){
				    Session::flash('status','Cart Deleted Successfully');
				    return redirect('client/add_package/'.base64_encode($client_id));
				}
			}
		}
	}
	
	public function emptycart($c_id = NULL){
		$client_id = base64_decode($c_id);
		$order_cart_delete = DB::table('order_cart')->where('client_id',$client_id)->delete();
		$order_cart_details_delete = DB::table('order_cart_details')->where('client_id',$client_id)->delete();
		if ($order_cart_delete) {
			Session::flash('status','Cart Deleted Successfully');
			return redirect('client/add_package/'.base64_encode($client_id));
		}
	}
    
    public function random_number_generate(){
        $code = $this->generateRandomString(6);// it should be dynamic and unique 
        echo $code;
    }

    public  function generateRandomString($length = 20) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

}
